package com.hyva.hotel.respositories;

import com.hyva.hotel.entities.Orders;
import com.hyva.hotel.entities.RelOrdersServices;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RelOrderServicesRepository extends CrudRepository<RelOrdersServices, Long> {
    List<RelOrdersServices> findByOrderId(Orders orders);

}
