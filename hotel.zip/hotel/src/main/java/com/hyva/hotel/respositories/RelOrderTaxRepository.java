package com.hyva.hotel.respositories;

import com.hyva.hotel.entities.Orders;
import com.hyva.hotel.entities.RelOrdersTaxes;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RelOrderTaxRepository extends CrudRepository<RelOrdersTaxes, Long> {
    List<RelOrdersTaxes> findByOrderId(Orders orders);

}
