package com.hyva.hotel.respositories;

import com.hyva.hotel.entities.Payment;
import org.springframework.data.repository.CrudRepository;

public interface PaymentRepository extends CrudRepository<Payment, Long> {
}
