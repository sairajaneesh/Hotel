package com.hyva.hotel.pojo;

public class AmenitiesPojo {
    private Long acdyrId;
    private String name;
    private String active;
    private String image;
    private String description;

    public Long getAcdyrId() {
        return acdyrId;
    }

    public void setAcdyrId(Long acdyrId) {
        this.acdyrId = acdyrId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
