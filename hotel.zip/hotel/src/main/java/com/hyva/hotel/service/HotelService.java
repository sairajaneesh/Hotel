package com.hyva.hotel.service;

import com.hyva.hotel.entities.*;
import com.hyva.hotel.entities.Currency;
import com.hyva.hotel.pojo.*;
import com.hyva.hotel.mapper.*;
import com.hyva.hotel.respositories.*;
import com.hyva.hotel.util.ObjectMapperUtils;
//import com.sun.xml.internal.bind.v2.runtime.reflect.Lister;
import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.html.WebColors;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.LineSeparator;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Struct;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;


@Component
public class HotelService {

    @Autowired
    BsUserRepository bsUserRepository;
    @Autowired
    HotelFloorRepository hotelFloorRepository;
    @Autowired
    HotelRoomTypesRepository hotelRoomTypesRepository;
    @Autowired
    HotelRoomsRepository hotelRoomsRepository;
    @Autowired
    HotelTaxRepository hotelTaxRepository;
    @Autowired
    HotelUserRepository hotelUserRepository;
    @Autowired
    ServicesRepository servicesRepository;
    @Autowired
    RelOrderServicesRepository relOrderServicesRepository;
    @Autowired
    RelOrderPriceRepository relOrderPriceRepository;
    @Autowired
    OrdersRepository ordersRepository;
    @Autowired
    HotelGuestsRepository hotelGuestsRepository;
    @Autowired
    PaymentRepository paymentRepository;
    @Autowired
    StateRepository stateRepository;
    @Autowired
    CountryRepository countryRepository;
    @Autowired
    CurrencyRepository currencyRepository;
    @Autowired
    HotelPriceManagerRepository hotelPriceManagerRepository;
    @Autowired
    RelOrderTaxRepository relOrderTaxRepository;
    @Autowired
    PaymentMethodRepository paymentMethodRepository;
    @Autowired
    AmenitiesRepository amenitiesRepository;
    @Autowired
    HouseKeepingRepository houseKeepingRepository;
    @Autowired
    DepartmentsRepository departmentsRepository;
    @Autowired
    DesignationRepository designationRepository;
    @Autowired
    EmployeesRepository employeesRepository;
    @Autowired
    ExpenseCategoryRepository expenseCategoryRepository;
    @Autowired
    ExpenseRepository expenseRepository;
    @Autowired
    SalesDiscountRepository salesDiscountRepository;
    @Autowired
    TestimonialsRepository testimonialsRepository;
    @Autowired
    HotelCurrencyRepository hotelCurrencyRepository;
    @Autowired
    LanguageRepository languageRepository;
    @Autowired
    CityRepository cityRepository;
    @Autowired
    EmailTemplateRepository emailTemplateRepository;
    @Autowired
    CouponsRepository couponsRepository;
    @Autowired
    FormSetupRepository formSetupRepository;
    @Autowired
    ConfiguratorRepository configuratorRepository;
    @Autowired
    PosMailRepository posMailRepository;
    int paginatedConstants=5;

    public User userValidate(UserPojo userPojo) {
        User user = bsUserRepository.findByUserNameAndPasswordUserAndStatus(
                userPojo.getUserName(), userPojo.getPasswordUser(),"Active");
        if (user != null) {
            return user;
        } else {
            return null;
        }
    }

    public User saveUserDetails(UserPojo userPojo) {
        User user = null;
        user = bsUserRepository.findByEmail(userPojo.getEmail());
        if (user != null) {
            user = null;
        } else {
            user = UserMapper.mapPojoToEntity(userPojo);
            bsUserRepository.save(user);
        }
        return user;
    }

    public Floors saveFloors(FloorsPojo floorsPojo){
        List<Floors> list=new ArrayList<>();
        if(floorsPojo.getId()!=0){
            list=hotelFloorRepository.findByNameAndIdNotIn(floorsPojo.getName(),floorsPojo.getId());
        }
        else {
            list=hotelFloorRepository.findByName(floorsPojo.getName());
        }
       if(list.size()==0){
           Floors floors = null;
           floors = FloorMapper.mapPojoToEntity(floorsPojo);
           hotelFloorRepository.save(floors);
           return floors;
       }
       else{
            return null;
       }
    }

    public Configurator saveConfigurator(ConfiguratorPojo pojo) throws JSONException {
        Configurator configurator=null;
        List<Configurator> list=configuratorRepository.findAll();
        if(list.size()>0)
        configurator=list.get(0);
        if(configurator==null){
            configurator=new Configurator();
        }else {
            pojo.setId(configurator.getId());
        }
        configurator = ConfiguratorMapper.mapPojoToEntity(pojo);
        configuratorRepository.save(configurator);
        return configurator;
    }

    public void getDeleteFloors(Long id){
        hotelFloorRepository.delete(id);
    }

   public void getDeleteRoomTypes(Long id){
        hotelRoomTypesRepository.delete(id);
   }
   public void getDeleteCoupons(Long id){
        couponsRepository.delete(id);
   }
    public List<FloorsPojo> getFloorsList3() {
        List<Floors> floors = new ArrayList<>();
        floors = (List<Floors>) hotelFloorRepository.findAll();
        List<FloorsPojo> floorsPojoList = ObjectMapperUtils.mapAll(floors, FloorsPojo.class);
        return floorsPojoList;
    }
    public List<AmenitiesPojo> getAmenetiesList() {
        List<Amenities> amenities = new ArrayList<>();
        amenities = (List<Amenities>) amenitiesRepository.findAll();
        List<AmenitiesPojo> amenitiesPojoList = ObjectMapperUtils.mapAll(amenities, AmenitiesPojo.class);
        return amenitiesPojoList;
    }
    public List<HouseKeepingStatusPojo> getHouseKeepingList() {
        List<HouseKeepingStatus> houseKeepingStatus = new ArrayList<>();
        houseKeepingStatus = (List<HouseKeepingStatus>) houseKeepingRepository.findAll();
        List<HouseKeepingStatusPojo> houseKeepingStatusPojoList = ObjectMapperUtils.mapAll(houseKeepingStatus, HouseKeepingStatusPojo.class);
        return houseKeepingStatusPojoList;
    }
    public List<DepartmentsPojo> getdepartmentsList() {
        List<Departments> departments = new ArrayList<>();
        departments = (List<Departments>) departmentsRepository.findAll();
        List<DepartmentsPojo> departmentsPojoList = ObjectMapperUtils.mapAll(departments, DepartmentsPojo.class);
        return departmentsPojoList;
    }
    public List<DesignationPojo> getdesignationList() {
        List<Designation> designation = new ArrayList<>();
        designation = (List<Designation>) designationRepository.findAll();
        List<DesignationPojo> designationPojoList = ObjectMapperUtils.mapAll(designation, DesignationPojo.class);
        return designationPojoList;
    }
    public List<EmailTemplatePojo> getemailList() {
        List<Email_Templete> email_templetes = new ArrayList<>();
        email_templetes = (List<Email_Templete>) emailTemplateRepository.findAll();
        List<EmailTemplatePojo> emailTemplatePojos = ObjectMapperUtils.mapAll(email_templetes, EmailTemplatePojo.class);
        return emailTemplatePojos;
    }


    public RoomTypesPojo saveRoomTypes(RoomTypesPojo roomTypespojo) throws JSONException {
        List<RoomTypes> list=new ArrayList<>();
        if(roomTypespojo.getId()!=0) {
            list = hotelRoomTypesRepository.findByTitleAndIdNotIn(roomTypespojo.getTitle(), roomTypespojo.getId());
        }
        else {
            list=hotelRoomTypesRepository.findByTitle(roomTypespojo.getTitle());
        }
        if(list.size()==0){
            RoomTypes roomTypes = null;
            roomTypes = HotelRoomTypeMapper.mapPojoToEntity(roomTypespojo);
            hotelRoomTypesRepository.save(roomTypes);
            return roomTypespojo;
        }
        else{
            return null;
        }

    }
    public CouponsPojo savecoupon(CouponsPojo couponsPojo) throws JSONException {
        List<Coupons> list=new ArrayList<>();
        if(couponsPojo.getId()!=null) {
            list = couponsRepository.findByTitleAndIdNotIn(couponsPojo.getTitle(), couponsPojo.getId());
        }
        else {
            list=couponsRepository.findByTitle(couponsPojo.getTitle());
        }
        if(list.size()==0){
            Coupons coupons = null;
            coupons = CouponsMapper.mapPojoToEntity(couponsPojo);
            couponsRepository.save(coupons);
            return couponsPojo;
        }
        else{
            return null;
        }

    }
    public Coupons getcoupon(String couponsPojo) throws JSONException {
        Coupons coupons=couponsRepository.findByCodeLike(couponsPojo);
        return coupons;
    }
    public RoomsPojo saveRooms(RoomsPojo roomspojo) throws JSONException {
        List<Rooms>list=new ArrayList<>();
        if(roomspojo.getId()!=0){
            list=hotelRoomsRepository.findByRoomnoAndIdNotIn(roomspojo.getRoomno(),roomspojo.getId());
        }
        else{
            list=hotelRoomsRepository.findByRoomno(roomspojo.getRoomno());
        }
        if(list.size()==0){
            Rooms rooms = null;
            RoomTypes roomTypesObj = hotelRoomTypesRepository.findOne(roomspojo.getRoom_typeId());
            Floors floorsObj = hotelFloorRepository.findOne(roomspojo.getFloor_Id());
            roomspojo.setFloorId(floorsObj);
            roomspojo.setRoomTypeId(roomTypesObj);
            rooms = HotelRoomsMapper.mapPojoToEntity(roomspojo);
            hotelRoomsRepository.save(rooms);
            return roomspojo;
        }
        else{
            return null;
        }

    }
    public List<RoomsPojo> getRoomsList() {
        List<Rooms> rooms = new ArrayList<>();
        rooms = (List<Rooms>) hotelRoomsRepository.findAll();
        List<RoomsPojo> roomsPojo = ObjectMapperUtils.mapAll(rooms, RoomsPojo.class);
        for(RoomsPojo roomsPojo1:roomsPojo){
            roomsPojo1.setFloor_Id(roomsPojo1.getFloorId().getId());
            roomsPojo1.setRoom_typeId(roomsPojo1.getRoomTypeId().getId());
        }
        return roomsPojo;
    }

    public List<Rooms> getEmptyRoomList(Long roomTypeId,Date fromDate,Date toDate) {
        RoomTypes roomTypesObj = hotelRoomTypesRepository.findById(roomTypeId);
        List<RelOrdersPrices> list=relOrderPriceRepository.findAllByDateBetween(fromDate,toDate);
        List<String> roomNo=new ArrayList<>();
        for(RelOrdersPrices relOrdersPrices:list){
            if(StringUtils.equalsIgnoreCase(relOrdersPrices.getOrderId().getBookingstatus(),"Normal")) {
                roomNo.add(relOrdersPrices.getOrderId().getRoom_no());
            }
        }
        List<Rooms> roomsList = new ArrayList<>();
        if(roomNo.size()>0){
            roomsList=hotelRoomsRepository.findAllByRoomTypeIdAndRoomnoNotIn(roomTypesObj,roomNo);
        }else {
            roomsList=hotelRoomsRepository.findByRoomTypeId(roomTypesObj);
        }
        return roomsList;
    }

    public OrdersPojo saveDiscount(OrdersPojo ordersPojo){
        Orders orders=ordersRepository.findOne(ordersPojo.getId());
        orders.setDiscountAmt(ordersPojo.getDiscountAmt());
        orders.setDiscount(ordersPojo.getDiscount());
        orders.setDescription(ordersPojo.getDescription());
        orders.setAmount(ordersPojo.getAmount());
        orders.setTaxamount(ordersPojo.getTaxamount());
        orders.setTotalamount(ordersPojo.getTotalamount());
        List<RelOrdersTaxes> list=relOrderTaxRepository.findByOrderId(orders);
        relOrderTaxRepository.delete(list);
        for(RelOrderTaxesPojo relOrderTaxesPojo : ordersPojo.getRelOrderTaxesPojoList()){
            RelOrdersTaxes relOrdersTaxes = new RelOrdersTaxes();
            relOrdersTaxes.setOrderId(orders);
            taxes taxesObj = hotelTaxRepository.findByName(relOrderTaxesPojo.getName()).get(0);
            relOrdersTaxes.setTaxId(taxesObj);
            relOrdersTaxes.setAmount(relOrderTaxesPojo.getTotal());
            relOrderTaxRepository.save(relOrdersTaxes);
        }
        ordersRepository.save(orders);

        return ordersPojo;
    }

    public OrdersPojo saveAdvancePayment(OrdersPojo ordersPojo){
        Orders orders=ordersRepository.findOne(ordersPojo.getId());
        orders.setAdvance_amount(orders.getAdvance_amount()+ordersPojo.getAdvance_amount());
        ordersRepository.save(orders);
        return ordersPojo;
    }

    public OrdersPojo saveItemPayment(OrdersPojo ordersPojo){
        Orders orders=ordersRepository.findOne(ordersPojo.getId());
        orders.setItemtotal(ordersPojo.getItemtotal());
        orders.setRoom_no(ordersPojo.getRoom_no());
        orders.setItemName(ordersPojo.getItemName());
        orders.setTotalamount(orders.getTotalamount()+ordersPojo.getItemtotal());
        orders.setAmount(orders.getAmount()+ordersPojo.getItemtotal());
        ordersRepository.save(orders);
        return ordersPojo;
    }
    public OrdersPojo saveCheckinRoom(OrdersPojo ordersPojo){
        Orders orders=ordersRepository.findOne(ordersPojo.getId());
        orders.setRoom_no(ordersPojo.getRoom_no());
        orders.setBookingstatus("Normal");
        ordersRepository.save(orders);
        return ordersPojo;
    }
    public void DeleteRooms(Long id){
        hotelRoomsRepository.delete(id);
    }

    public UserPojo getuserDetails(UserPojo userPojo){
        List<User>list=new ArrayList<>();
        if(userPojo.getUseraccountId()!=null){
            list=hotelUserRepository.findByUserNameAndUseraccountIdNotIn(userPojo.getUserName(), userPojo.getUseraccountId());
        }
        else {
            list=hotelUserRepository.findByUserName(userPojo.getUserName());
        }
        if(list.size()==0){
            User user = UserMapper.mapPojoToEntity(userPojo);
            hotelUserRepository.save(user);
            return userPojo;
        }else{
            return null;
        }

    }
    public EmployeesPojo saveEmployee(EmployeesPojo employeesPojo) {
        List<Employees>list=new ArrayList<>();
        if(employeesPojo.getId()!=null){
            list=employeesRepository.findByUsernameAndIdNotIn(employeesPojo.getUsername(),employeesPojo.getId());
        }
        else {
            list=employeesRepository.findByUsername(employeesPojo.getUsername());
        }
        if(list.size()==0){
            Employees employees = EmployeesMapper.mapPojoToEntity(employeesPojo);
            employeesRepository.save(employees);
            return employeesPojo;
        }else{
            return null;
        }

    }
    public ExpensesCategoryPojo saveexpensecategory(ExpensesCategoryPojo expensesCategoryPojo){
        List<ExpensesCategory>list=new ArrayList<>();
        if(expensesCategoryPojo.getId()!=null){
            list=expenseCategoryRepository.findByNameAndIdNotIn(expensesCategoryPojo.getName(),expensesCategoryPojo.getId());
        }
        else {
            list=expenseCategoryRepository.findByName(expensesCategoryPojo.getName());
        }
        if(list.size()==0){
            ExpensesCategory expensesCategory = ExpenseCategoryMapper.mapPojoToEntity(expensesCategoryPojo);
            expenseCategoryRepository.save(expensesCategory);
            return expensesCategoryPojo;
        }else{
            return null;
        }

    }
    public ExpensesPojo saveexpense(ExpensesPojo expensesPojo) {
        List<Expanses>list=new ArrayList<>();
        if(expensesPojo.getId()!=null){
            list=expenseRepository.findByTitleAndIdNotIn(expensesPojo.getTitle(),expensesPojo.getId());
        }
        else {
            list=expenseRepository.findByTitle(expensesPojo.getTitle());
        }
        if(list.size()==0){
            Expanses expanses = ExpenseMapper.mapPojoToEntity(expensesPojo);
            expenseRepository.save(expanses);
            return expensesPojo;
        }else{
            return null;
        }

    }
    public SalesDiscountPojo saveSales(SalesDiscountPojo salesDiscountPojo) {
        List<SalesDiscount>list=new ArrayList<>();
        if(salesDiscountPojo.getId()!=null){
            list=salesDiscountRepository.findByItemNameAndIdNotIn(salesDiscountPojo.getItemName(),salesDiscountPojo.getId());
        }
        else {
            list=salesDiscountRepository.findByItemName(salesDiscountPojo.getItemName());
        }
        if(list.size()==0){
            SalesDiscount salesDiscount = SalesDiscountMapper.mapPojoToEntity(salesDiscountPojo);
            salesDiscountRepository.save(salesDiscount);
            return salesDiscountPojo;
        }else{
            return null;
        }

    }
    public TestimonialsPojo saveTestimonials(TestimonialsPojo testimonialsPojo)  {
        List<Testimonials>list=new ArrayList<>();
        if(testimonialsPojo.getId()!=null){
            list=testimonialsRepository.findByAutherNameAndIdNotIn(testimonialsPojo.getAutherName(),testimonialsPojo.getId());
        }
        else {
            list=testimonialsRepository.findByAutherName(testimonialsPojo.getAutherName());
        }
        if(list.size()==0){
            Testimonials testimonials = TestimonialsMapper.mapPojoToEntity(testimonialsPojo);
            testimonialsRepository.save(testimonials);
            return testimonialsPojo;
        }else{
            return null;
        }

    }
    public List<Expanses> getExpenseCustomDatesReport(Date fromDate,Date toDate){
        List<Expanses> list=expenseRepository.findAllByDateBetween(fromDate,toDate);
        return  list;
    }
    public List<RelOrderPricesPojo> getGuestReport(Date fromDate,Date toDate){
        List<RelOrdersPrices> list=relOrderPriceRepository.findAllByDateBetween(fromDate,toDate);
        List<RelOrderPricesPojo> relOrderPricesPojos=OrdersMapper.relOrderPriceToPojo(list);
        return relOrderPricesPojos;
    }
    public List<RelOrdersPrices> getOccupancyReport(Date fromDate,Date toDate){
        List<RelOrdersPrices> list=relOrderPriceRepository.findAllByDateBetween(fromDate, toDate);
        return list;
    }
    public List<UserPojo> getUserList() {
        List<User> user = (List<User>) hotelUserRepository.findAll();
        List<UserPojo> usersPojo1 = ObjectMapperUtils.mapAll(user, UserPojo.class);
        return usersPojo1;
    }
    public List<ExpensesCategoryPojo> getExpenseCategoryList() {
        List<ExpensesCategory> expensesCategories = (List<ExpensesCategory>) expenseCategoryRepository.findAll();
        List<ExpensesCategoryPojo> expensesCategoryPojo = ObjectMapperUtils.mapAll(expensesCategories, ExpensesCategoryPojo.class);
        return expensesCategoryPojo;
    }
    public List<ExpensesPojo> getExpenseList() {
        List<Expanses> expanses = (List<Expanses>) expenseRepository.findAll();
        List<ExpensesPojo> expensesPojos = ObjectMapperUtils.mapAll(expanses, ExpensesPojo.class);
        return expensesPojos;
    }
    public List<TestimonialsPojo> getTestimonialsList() {
        List<Testimonials> testimonials = (List<Testimonials>) testimonialsRepository.findAll();
        List<TestimonialsPojo> testimonialsPojos = ObjectMapperUtils.mapAll(testimonials, TestimonialsPojo.class);
        return testimonialsPojos;
    }
    public List<SalesDiscountPojo> getsalesList() {
        List<SalesDiscount> salesDiscounts = (List<SalesDiscount>) salesDiscountRepository.findAll();
        List<SalesDiscountPojo> salesDiscountPojos = ObjectMapperUtils.mapAll(salesDiscounts, SalesDiscountPojo.class);
        return salesDiscountPojos;
    }
    public List<EmployeesPojo> getEmployeesList() {
        List<Employees> employees = (List<Employees>) employeesRepository.findAll();
        List<EmployeesPojo> employeesPojos = ObjectMapperUtils.mapAll(employees, EmployeesPojo.class);
        return employeesPojos;
    }
    public List<LanguagePojo> getlanguageList() {
        List<Language> languages = (List<Language>) languageRepository.findAll();
        List<LanguagePojo> languagePojos = ObjectMapperUtils.mapAll(languages, LanguagePojo.class);
        return languagePojos;
    }
    public void getDeleteUser(Long useraccountId) {
        hotelUserRepository.delete(useraccountId);
    }
    public void getDeleteLanguage(Long id) {
        languageRepository.delete(id);
    }

    public void DeleteExpenseCategory(Long id) {
        expenseCategoryRepository.delete(id);
    }
    public void DeleteExpense(Long id) {
        expenseRepository.delete(id);
    }
    public void getDeleteTestimonials(Long id) {
        testimonialsRepository.delete(id);
    }
    public void DeleteSales(Long id) {
        salesDiscountRepository.delete(id);
    }
    public void getDeleteEmployees(Long id) {
        employeesRepository.delete(id);
    }
    public void getDeleteConfigurator(Long id) {
        configuratorRepository.delete(id);
    }

    public TaxPojo saveTax(TaxPojo taxPojo){
        List<taxes>list=new ArrayList<>();
        if(taxPojo.getId()!=0){
            list=hotelTaxRepository.findByNameAndIdNotIn(taxPojo.getName(),taxPojo.getId());
        }
        else{
            list= hotelTaxRepository.findByName(taxPojo.getName());
        }
        if(list.size()==0){
            taxes tax = TaxMapper.mapPojoToEntity(taxPojo);
            hotelTaxRepository.save(tax);
            return taxPojo;
        }
       else {
            return null;
        }
    }

    public List<TaxPojo> getTaxList() {
        List<taxes> taxes = (List<taxes>) hotelTaxRepository.findAll();
        List<TaxPojo> taxPojos = ObjectMapperUtils.mapAll(taxes, TaxPojo.class);
        return taxPojos;
    }
    public List<ConfiguratorPojo> getConfiguratorList() {
        List<Configurator> configurators = (List<Configurator>) configuratorRepository.findAll();
        List<ConfiguratorPojo> configuratorPojos = ObjectMapperUtils.mapAll(configurators, ConfiguratorPojo.class);
        return configuratorPojos;
    }
    public void getDeleteTaxManager(Long id){
        hotelTaxRepository.delete(id);
    }
    public ServicesPojo savePaidServices(ServicesPojo servicesPojo) throws JSONException {
        List<Services>list=new ArrayList<>();
        if(servicesPojo.getId()!=0){
            list=servicesRepository.findByTitleAndIdNotIn(servicesPojo.getTitle(),servicesPojo.getId());
        }
        else{
            list= servicesRepository.findByTitle(servicesPojo.getTitle());
        }
        if(list.size()==0){
            RoomTypes roomTypesObj = hotelRoomTypesRepository.findById(servicesPojo.getRoomTypeId());
            servicesPojo.setRoomTypes(roomTypesObj);
            Services services = ServiceMapper.mapPojoToEntity(servicesPojo);
            servicesRepository.save(services);
            return servicesPojo;
        }else {
            return null;
        }

    }
    public void getDeletePaidServices(Long id){
        servicesRepository.delete(id);
    }
    public List<ServicesPojo> getServicesList() {
        List<Services> services = (List<Services>) servicesRepository.findAll();
        List<ServicesPojo> servicesPojos = ObjectMapperUtils.mapAll(services, ServicesPojo.class);
        for(ServicesPojo servicesPojo1:servicesPojos){
           servicesPojo1.setRoomTypeId(servicesPojo1.getRoomTypes().getId());
        }
        return servicesPojos;
    }

    public List<ServicesPojo> getServiceListBasedOnRoomType(Long roomTypeId) {
        if (roomTypeId != null) {
            RoomTypes roomTypesObj = hotelRoomTypesRepository.findOne(roomTypeId);
            List<Services> services = (List<Services>) servicesRepository.findByRoomTypes(roomTypesObj);
            List<ServicesPojo> servicesPojos = ObjectMapperUtils.mapAll(services, ServicesPojo.class);
            return servicesPojos;
        }else {
            return null;
        }
    }
    public List<TaxPojo> getTaxData() {
        List<taxes> taxesList = hotelTaxRepository.findByStatus("Active");
        List<TaxPojo> taxPojoList = ObjectMapperUtils.mapAll(taxesList, TaxPojo.class);
        return taxPojoList;
    }

    public OrdersPojo   saveOrderService(OrdersPojo ordersPojo) throws JSONException {
        if(ordersPojo.getGuest_id()!=null) {
            Guests guestsObj = hotelGuestsRepository.findOne(ordersPojo.getGuest_id());
            ordersPojo.setGuestId(guestsObj);
        }
        Orders ordersObj = OrdersMapper.mapPojoToEntity(ordersPojo);
        List<Orders> orderNumberObj = ordersRepository.findByOrderByIdDesc();
        if(orderNumberObj.size() == 0){
            ordersObj.setOrder_no(String.format("%06d", 1));
        }else {
            String orderNo = orderNumberObj.get(0).getOrder_no();
            if (!StringUtils.isEmpty(orderNo)) {
                int orderval = Integer.parseInt(orderNo);
                ordersObj.setOrder_no(String.format("%06d", ++orderval));
            }
        }
        Orders orders = ordersRepository.save(ordersObj);
        for(RelOrderServicesPojo relOrderServicesPojo : ordersPojo.getRelOrderServicesPojoList()){
            RelOrdersServices relOrdersServices = new RelOrdersServices();
            Services servicesObj = servicesRepository.findByTitle(relOrderServicesPojo.getTitle()).get(0);
            relOrdersServices.setServiceId(servicesObj);
            relOrdersServices.setOrderId(orders);
            OrdersMapper.relOrderServicePojoTOEntity(relOrderServicesPojo);
            relOrderServicesRepository.save(relOrdersServices);
        }
        for(RelOrderPricesPojo relOrderPricesPojo : ordersPojo.getRelOrderPricesPojoList()){
            RelOrdersPrices relOrdersPrices = new RelOrdersPrices();
            relOrdersPrices.setPrice(relOrderPricesPojo.getPrice());
            relOrdersPrices.setAdditional_person(relOrderPricesPojo.getAdditionalPerson());
            relOrdersPrices.setAdditional_person_price(relOrderPricesPojo.getAdditionalPersonPrice());
            relOrdersPrices.setTotal(relOrderPricesPojo.getTotalAmount());
            relOrdersPrices.setDate(relOrderPricesPojo.getDate());
              relOrdersPrices.setOrderId(orders);
            relOrderPriceRepository.save(relOrdersPrices);
        }
        for(RelOrderTaxesPojo relOrderTaxesPojo : ordersPojo.getRelOrderTaxesPojoList()){
            RelOrdersTaxes relOrdersTaxes = new RelOrdersTaxes();
            relOrdersTaxes.setOrderId(orders);
            taxes taxesObj = hotelTaxRepository.findByName(relOrderTaxesPojo.getName()).get(0);
            relOrdersTaxes.setTaxId(taxesObj);
            relOrdersTaxes.setAmount(relOrderTaxesPojo.getTotal());
            relOrderTaxRepository.save(relOrdersTaxes);
        }
        ordersPojo.setOrder_no(ordersObj.getOrder_no());
        return ordersPojo;
    }
    public static String getNextRefInvoice(String prefix, String nextRef) {
        StringBuilder sb = new StringBuilder();
        return sb.append(prefix).append(nextRef).toString();
    }
    public PaymentPojo savePaymentService(PaymentPojo paymentPojo) throws JSONException {
        Orders orders = ordersRepository.findOne(paymentPojo.getOrder_Id());
        FormSetUp formSetUp=new FormSetUp();
        formSetUp=formSetupRepository.findAllByTypename("OrderInvoiceNo");
        Payment paymentinv=new Payment();
        orders.setPayment_status("Checkout");
        paymentPojo.setOrderId(orders);
        paymentinv.setInvoice(getNextRefInvoice(formSetUp.getTypeprefix(), formSetUp.getNextref()));
        orders.setInvoice(getNextRefInvoice(formSetUp.getTypeprefix(), formSetUp.getNextref()));
        int incValue = Integer.parseInt(formSetUp.getNextref());
        paymentPojo.setInvoiceNo(getNextRefInvoice(formSetUp.getTypeprefix(), String.format("%08d", ++incValue)));
        formSetUp.setNextref(String.format("%08d", incValue));
        formSetupRepository.save(formSetUp);
        Payment payment = PaymentMapper.paymentPojoToEntity(paymentPojo);
        paymentRepository.save(payment);
        ordersRepository.save(orders);
        return paymentPojo;
    }
    public List<StatePojo> getStateListBasedOnCountry(String country1){
        List<State> stateList=stateRepository.findAllByCountryNameAndStatus(country1,"Active");
        List<StatePojo> statePojos=StateMapper.mapStateEntityToPojo(stateList);
        return statePojos;
    }
    public List<CityPojo> getCityListBasedonState(String state){
        List<Cities> cities=cityRepository.findAllByState(state);
        List<CityPojo> cityPojos=CityMapper.mapCitiesEntityToPojo(cities);
        return cityPojos;
    }
    public List<DesignationPojo> getDesignationListBasedOnDepartment(String department){
        List<Designation> designationList = new ArrayList<>();
        if(StringUtils.isEmpty(department)){
            designationList=designationRepository.findAll();
        }else{
            designationList=designationRepository.findAllByDeptname(department);
        }

        List<DesignationPojo> designationPojoList=DesignationsMapper.mapEntityToPojo(designationList);
        return designationPojoList;
    }

    public PriceManagerPojo savePriceManager(PriceManagerPojo priceManagerPojo) throws JSONException {
        List<PriceManager> list = new ArrayList<>();
        if (priceManagerPojo.getId() != 0) {
            list = hotelPriceManagerRepository.findByIdNotInAndRoomtypeAndFromDateAndToDate(priceManagerPojo.getId(),priceManagerPojo.getRoomtype(),priceManagerPojo.getFromDate(),priceManagerPojo.getToDate());
        } else {
            list = hotelPriceManagerRepository.findByRoomtypeAndFromDateAndToDate(priceManagerPojo.getRoomtype(),priceManagerPojo.getFromDate(),priceManagerPojo.getToDate());
        }
        if (list.size() == 0) {
            PriceManager priceManager = null;
            if (priceManager == null) {
                priceManager = HotelPriceManagerMapper.mapPojoToEntity(priceManagerPojo);
                hotelPriceManagerRepository.save(priceManager);
                return priceManagerPojo;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    public State saveState(StatePojo statePojo) {
        State state1=new State();
        if(statePojo.getId()!=null){
            state1=stateRepository.findByStateNameAndIdNotIn(statePojo.getStateName(),statePojo.getId());
        }else {
            state1=stateRepository.findByStateName(statePojo.getStateName());
        }
        if(state1==null) {
            State state = StateMapper.mapStatePojoToEntity(statePojo);
            Country country = countryRepository.findByCountryName(statePojo.getCountry());
            if(country!=null)
            state.setCountryName(country.getCountryName());
            stateRepository.save(state);
            return state;
        }else {
            return null;
        }
    }
    public BasePojo getStateList(String status,BasePojo basePojo,String searchText) {
        List<State> list = new ArrayList<>();
        basePojo.setPageSize(5);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.ASC,"stateName"));
        if(basePojo.isLastPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.DESC,"stateName"));
        }
//        if(StringUtils.isEmpty(status)){
//            status="Active";
//        }
        State state=new State();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),5,sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.DESC,"stateName"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            state=stateRepository.findFirstByStateCodeContainingOrStateNameContaining(searchText,searchText,sort);
            list = stateRepository.findAllByStateCodeContainingOrStateNameContaining(searchText,searchText,pageable);
        } else {
            state=stateRepository.findFirstBy(sort);
            list = stateRepository.findAllBy(pageable);
        }
        if(list.contains(state)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<StatePojo> stateList =StateMapper.mapStateEntityToPojo(list);
        basePojo=calculatePagination(basePojo,stateList.size());
        basePojo.setList(stateList);
        return basePojo;
    }
    public BasePojo calculatePagination(BasePojo basePojo,int size){
        if(basePojo.isLastPage()==true){
            basePojo.setFirstPage(false);
            basePojo.setNextPage(true);
            basePojo.setPrevPage(false);
        }else if(basePojo.isFirstPage()==true){
            basePojo.setLastPage(false);
            basePojo.setNextPage(false);
            basePojo.setPrevPage(true);
            if(basePojo.isStatus()==true){
                basePojo.setLastPage(true);
                basePojo.setNextPage(true);
            }
        }else if(basePojo.isNextPage()==true){
            basePojo.setLastPage(false);
            basePojo.setFirstPage(false);
            basePojo.setPrevPage(false);
            basePojo.setNextPage(false);
            if(basePojo.isStatus()==true){
                basePojo.setLastPage(true);
                basePojo.setNextPage(true);
            }
        }else if(basePojo.isPrevPage()==true){
            basePojo.setLastPage(false);
            basePojo.setFirstPage(false);
            basePojo.setNextPage(false);
            basePojo.setPrevPage(false);
            if(basePojo.isStatus()==true){
                basePojo.setPrevPage(true);
                basePojo.setFirstPage(true);
            }
        }
        if(size==0){
            basePojo.setLastPage(true);
            basePojo.setFirstPage(true);
            basePojo.setNextPage(true);
            basePojo.setPrevPage(true);
        }
        return basePojo;
    }

    public StatePojo editState(String stateName) {
        State state = stateRepository.findByStateName(stateName);
        List<State> states = new ArrayList<>();
        states.add(state);
        StatePojo statePojo = StateMapper.mapStateEntityToPojo(states).get(0);
        return statePojo;
    }
   public CityPojo editCity(String name,String countryName,String state) {
        Cities cities = cityRepository.findByNameAndCountryAndState(name,countryName,state);
        List<Cities> cities1 = new ArrayList<>();
        cities1.add(cities);
        CityPojo cityPojo = CityMapper.mapCitiesEntityToPojo(cities1).get(0);
        return cityPojo;
    }

    public List<CountryPojo> getCountryList(String status) {
        List<Country> list = new ArrayList<>();
        if (StringUtils.isEmpty(status)) {
            list = (List<Country>) countryRepository.findAll();
        } else {
            list = countryRepository.findAllByStatus(status);
        }
        List<CountryPojo> country = CountryMapper.mapCountryEntityToPojo(list);
        return country;
    }
    public List<CityPojo> getCityList(String status) {
        List<Cities> list = new ArrayList<>();
        if (StringUtils.isEmpty(status)) {
            list = (List<Cities>) cityRepository.findAll();
        } else {
            list = cityRepository.findAllBy(status);
        }
        List<CityPojo> cityPojos = CityMapper.mapCitiesEntityToPojo(list);
        return cityPojos;
    }
    public void deleteState(String stateName) {
        stateRepository.delete(stateRepository.findByStateName(stateName));
    }
    public void deleteCity(String name,String countryName,String state) {
        cityRepository.delete(cityRepository.findByNameAndCountryAndState(name,countryName,state));
    }
    public Country saveCountry(CountryPojo countryPojo) {
        Country countries = new Country();
        if(countryPojo.getCountryId()!=null){
            countries=countryRepository.findByCountryNameAndCountryIdNotIn(countryPojo.getCountryName(),countryPojo.getCountryId());
        }
        else{
            countries=countryRepository.findByCountryName(countryPojo.getCountryName());
        }
        if(countries==null){
            Country country = CountryMapper.mapCountryPojoToEntity(countryPojo);
            countryRepository.save(country);
            return country;
        }else{
            return null;
        }

    }
    public Cities saveCity(CityPojo cityPojo) {
        Cities cities1 = new Cities();
        if(cityPojo.getId()!=null){
            cities1=cityRepository.findByNameAndCountryAndStateAndIdNotIn(cityPojo.getName(),cityPojo.getCountry(),cityPojo.getState(),cityPojo.getId());
        }
        else{
            cities1=cityRepository.findByNameAndCountryAndState(cityPojo.getName(),cityPojo.getCountry(),cityPojo.getState());
        }
        if(cities1==null){
            Cities cities = CityMapper.mapCityPojoToEntity(cityPojo);
            cityRepository.save(cities);
            return cities;
        }else{
            return null;
        }

    }
    public void deleteCountry(String countryName) {
        countryRepository.delete(countryRepository.findByCountryName(countryName));
    }

    public CountryPojo editCountry(String countryName) {
        Country country = countryRepository.findByCountryName(countryName);
        List<Country> countries = new ArrayList<>();
        countries.add(country);
        CountryPojo countryPojo = CountryMapper.mapCountryEntityToPojo(countries).get(0);
        return countryPojo;
    }

    public Currency1 saveCurrency(CurrencyPojo1 currencyPojo) {
        Currency1 currency = new Currency1();
        if(currencyPojo.getCurrencyId()!=null){
            currency=currencyRepository.findByCurrencyNameAndCurrencyIdNotIn(currencyPojo.getCurrencyName(),currencyPojo.getCurrencyId());

        }else{
            currency=currencyRepository.findByCurrencyName(currencyPojo.getCurrencyName());
        }
        if(currency==null){
            Currency1 currency1 = CurrencyMapper.mapCurrencyPojoToEntity(currencyPojo);
            currencyRepository.save(currency1);
            return currency1;
        }else{
            return  null;
        }

    }
    public List<CurrencyPojo1> getCurrencyList(String status) {
        List<Currency1> list = new ArrayList<>();
        if (StringUtils.isEmpty(status)) {
            list = currencyRepository.findAll();
        } else {
            list = currencyRepository.findAllByStatus(status);
        }

        List<CurrencyPojo1> currency1 = CurrencyMapper.mapCurrencyEntityToPojo(list);
        return currency1;
    }

    public void deleteCurrency(String  currencyName) {
        currencyRepository.delete(currencyRepository.findByCurrencyName(currencyName));
    }

    public CurrencyPojo1 editCurrency(String currencyName) {
        Currency1 currency = currencyRepository.findByCurrencyName(currencyName);
        List<Currency1> currencies = new ArrayList<>();
        currencies.add(currency);
        CurrencyPojo1 currencyPojo = CurrencyMapper.mapCurrencyEntityToPojo(currencies).get(0);
        return currencyPojo;
    }
    public PaymentMethod savePaymentMethod(PaymentMethodPojo paymentMethodPojo) {
        PaymentMethod paymentMethods =new PaymentMethod();
        if(paymentMethodPojo.getPaymentmethodId()!=null){
            paymentMethods=paymentMethodRepository.findByPaymentmethodNameAndPaymentmethodIdNotIn(paymentMethodPojo.getPaymentmethodName(),paymentMethodPojo.getPaymentmethodId());
        }else{
            paymentMethods=paymentMethodRepository.findByPaymentmethodName(paymentMethodPojo.getPaymentmethodName());
        }
        if(paymentMethods==null){
            PaymentMethod paymentMethod = PaymentMethodMapper.mapPaymentMethodPojoToEntity(paymentMethodPojo);
            paymentMethodRepository.save(paymentMethod);
            return paymentMethod;
        }else{
            return null;
        }

    }
    public void deletePaymentMethod(Long paymentmethodId) {
        paymentMethodRepository.delete(paymentmethodId);
    }

    public PaymentMethodPojo editPaymentMethod(Long agentId) {
        PaymentMethod paymentMethod = paymentMethodRepository.findOne(agentId);
        List<PaymentMethod> agentList = new ArrayList<>();
        agentList.add(paymentMethod);
        PaymentMethodPojo paymentMethodPojo = PaymentMethodMapper.mapPaymentMethodEntityToPojo(agentList).get(0);
        return paymentMethodPojo;
    }
    public List<PaymentMethodPojo> getPaymentMethodList(String status) {
        List<PaymentMethod> list = new ArrayList<>();
        if (StringUtils.isEmpty(status)) {
            list = paymentMethodRepository.findAll();
        } else {
            list = paymentMethodRepository.findAllByStatus(status);
        }
        List<PaymentMethodPojo> paymentMethodPojos = PaymentMethodMapper.mapPaymentMethodEntityToPojo(list);
        return paymentMethodPojos;
    }

    public void DeletePriceManager(Long id){
        hotelPriceManagerRepository.delete(id);
    }

    public List<RoomTypesPojo> getRoomTypesList() {
        List<RoomTypes> roomTypes = new ArrayList<>();
        roomTypes = (List<RoomTypes>) hotelRoomTypesRepository.findAll();
        List<RoomTypesPojo> roomTypesPojo = ObjectMapperUtils.mapAll(roomTypes, RoomTypesPojo.class);
        return roomTypesPojo;
    }
    public List<CouponsPojo> getcouponsList() {
        List<Coupons> coupons = new ArrayList<>();
        coupons = (List<Coupons>) couponsRepository.findAll();
        List<CouponsPojo> couponsPojos = ObjectMapperUtils.mapAll(coupons, CouponsPojo.class);
        return couponsPojos;
    }
    public List<OrdersPojo> getcheckinList(String status) {
        List<Orders> orders = new ArrayList<>();
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if (StringUtils.equalsIgnoreCase(status, "Normal")){
            orders=ordersRepository.findByBookingstatus(status,sort);
        }else{
            orders=ordersRepository.findByAdvanceBooking(true,sort);
        }
        List<OrdersPojo> ordersPojo = ObjectMapperUtils.mapAll(orders, OrdersPojo.class);
        for(OrdersPojo ordersPojo1:ordersPojo){
            RoomTypes roomTypes=hotelRoomTypesRepository.findOne(ordersPojo1.getRoom_type_id());
            ordersPojo1.setRoomTypeName(roomTypes.getTitle());
        }
        return ordersPojo;
    }
    public OrdersPojo getordersobj(Long id) {
        Orders orders = new Orders();
        orders = (Orders) ordersRepository.findOne(id);
        OrdersPojo ordersPojo = OrdersMapper.EntityToPojo(orders);
        return ordersPojo;
//        OrdersPojo ordersPojo = ObjectMapperUtils.mapAll(orders, Orders.class);
    }
    public List<RelOrdersPrices> getrelOrderPrices(Orders orders) {
       List<RelOrdersPrices> relOrdersPrices = new ArrayList<>();
        relOrdersPrices = ( List<RelOrdersPrices> ) relOrderPriceRepository.findByOrderId(orders);
        return relOrdersPrices;
    }
    public List<RelOrderTaxesPojo> getRelOrderTaxes(Orders orders) {
        List<RelOrdersTaxes> relOrdersTaxes = ( List<RelOrdersTaxes> ) relOrderTaxRepository.findByOrderId(orders);
        List<RelOrderTaxesPojo> taxPojoList = new ArrayList<>();
        for(RelOrdersTaxes taxes: relOrdersTaxes){
            RelOrderTaxesPojo relOrderTaxesPojo = new RelOrderTaxesPojo();
            relOrderTaxesPojo.setName(taxes.getTaxId().getName());
            relOrderTaxesPojo.setRate(taxes.getTaxId().getRate());
            relOrderTaxesPojo.setTotal(taxes.getAmount());
            taxPojoList.add(relOrderTaxesPojo);
        }
        return taxPojoList;
    }
  public List<RelOrderServicesPojo> getRelOrderServices(Orders orders) {
       List<RelOrdersServices> relOrdersServices = ( List<RelOrdersServices> ) relOrderServicesRepository.findByOrderId(orders);
      List<RelOrderServicesPojo> servicesPojoList = new ArrayList<>();
      for(RelOrdersServices services:relOrdersServices){
          RelOrderServicesPojo relOrderServicesPojo=new RelOrderServicesPojo();
          relOrderServicesPojo.setTitle(services.getServiceId().getTitle());
          if(!StringUtils.isEmpty(services.getServiceId().getPrice())) {
              relOrderServicesPojo.setPrice(Double.parseDouble(services.getServiceId().getPrice()));
          }
          relOrderServicesPojo.setPrice_type(services.getServiceId().getPrice_type());
          servicesPojoList.add(relOrderServicesPojo);
      }
        return servicesPojoList;
    }
    public List<PriceManagerPojo> getPriceManagerList() {
        List<PriceManager> priceManager = new ArrayList<>();
        priceManager = (List<PriceManager>) hotelPriceManagerRepository.findAll();
        List<PriceManagerPojo> priceManagerPojo = ObjectMapperUtils.mapAll(priceManager, PriceManagerPojo.class);
        for(PriceManagerPojo priceManagerPojo1:priceManagerPojo){
            priceManagerPojo1.setRoomtype(priceManagerPojo1.getRoomtype());
        }
        return priceManagerPojo;
    }

    public List<Rooms> roomList(Long roomTypeId) {
        RoomTypes roomTypesObj = hotelRoomTypesRepository.findById(roomTypeId);
        List<Rooms> roomsList = hotelRoomsRepository.findByRoomTypeId(roomTypesObj);
        return roomsList;
    }

    public RoomTypes roomTypeObj(Long roomTypeId) {
        RoomTypes roomTypesObj = hotelRoomTypesRepository.findById(roomTypeId);
        return roomTypesObj;
    }

    public GuestsPojo saveguests(GuestsPojo guestsPojo) throws JSONException {
        List<Guests>list=new ArrayList<>();
        if(guestsPojo.getId()!=0) {
             list = hotelGuestsRepository.findByFirstnameAndLastnameAndIdNotIn(guestsPojo.getFirstname(), guestsPojo.getLastname(), guestsPojo.getId());
        }
        else{
            list=hotelGuestsRepository.findByFirstnameAndLastname(guestsPojo.getFirstname(),guestsPojo.getLastname());
        }
        if(list.size()==0){
            Guests guests = null;
            guests = HotelGuestsMapper.mapPojoToEntity(guestsPojo);
            hotelGuestsRepository.save(guests);
            return guestsPojo;
        }
        else {
            return null;
        }
    }
    public LanguagePojo savelanguage(LanguagePojo languagePojo) throws JSONException {
        List<Language>list=new ArrayList<>();
        if(languagePojo.getId()!=null) {
             list = languageRepository.findByNameAndIdNotIn(languagePojo.getName(), languagePojo.getId());
        }
        else{
            list=languageRepository.findByName(languagePojo.getName());
        }
        if(list.size()==0){
            Language language = null;
            language = LanguageMapper.mapPojoToEntity(languagePojo);
            languageRepository.save(language);
            return languagePojo;
        }
        else {
            return null;
        }
    }
    public EmailTemplatePojo saveemail(EmailTemplatePojo emailTemplatePojo) throws JSONException {
        List<Email_Templete>list=new ArrayList<>();
        if(emailTemplatePojo.getId()!=null) {
             list = emailTemplateRepository.findByEmailAndIdNotIn(emailTemplatePojo.getEmail(), emailTemplatePojo.getId());
        }
        else{
            list=emailTemplateRepository.findByEmail(emailTemplatePojo.getEmail());
        }
        if(list.size()==0){
            Email_Templete email_templete = null;
            email_templete = EmailTemplateMapper.mapPojoToEntity(emailTemplatePojo);
            emailTemplateRepository.save(email_templete);
            return emailTemplatePojo;
        }
        else {
            return null;
        }
    }
    public AmenitiesPojo saveAmenities(AmenitiesPojo amenitiesPojo) throws JSONException {
        List<Amenities>list=new ArrayList<>();
        if(amenitiesPojo.getAcdyrId()!=0) {
             list = amenitiesRepository.findByNameAndAcdyrIdNotIn(amenitiesPojo.getName(),  amenitiesPojo.getAcdyrId());
        }
        else{
            list=amenitiesRepository.findByName(amenitiesPojo.getName());
        }
        if(list.size()==0){
            Amenities amenities = null;
            amenities = HotelAmenitiesMapper.mapPojoToEntity(amenitiesPojo);
            amenitiesRepository.save(amenities);
            return amenitiesPojo;
        }
        else {
            return null;
        }
    }

    public CurrencyPojo savecurrency(CurrencyPojo currencyPojo) throws JSONException {
        List<Currency>list=new ArrayList<>();
        if(currencyPojo.getId()!=null) {
             list = hotelCurrencyRepository.findByNameAndIdNotIn(currencyPojo.getName(),currencyPojo.getId());
        }
        else{
            list=hotelCurrencyRepository.findByName(currencyPojo.getName());
        }
        if(list.size()==0){
            Currency currency = null;
            currency = CurrencyMapper.mapPojoToEntity(currencyPojo);
            hotelCurrencyRepository.save(currency);
            return currencyPojo;
        }
        else {
            return null;
        }
    }
    public HouseKeepingStatusPojo saveHouse(HouseKeepingStatusPojo houseKeepingStatusPojo) throws JSONException {
        List<HouseKeepingStatus>list=new ArrayList<>();
        if(houseKeepingStatusPojo.getId()!=null) {
            list = houseKeepingRepository.findByTitleAndIdNotIn(houseKeepingStatusPojo.getTitle(),houseKeepingStatusPojo.getId());
        }
        else{
            list=houseKeepingRepository.findByTitle(houseKeepingStatusPojo.getTitle());
        }
        if(list.size()==0){
            HouseKeepingStatus houseKeepingStatus = null;
            houseKeepingStatus = HouseKeepingStatusMapper.mapPojoToEntity(houseKeepingStatusPojo);
            houseKeepingRepository.save(houseKeepingStatus);
            return houseKeepingStatusPojo;
        }
        else {
            return null;
        }
    }
    public DepartmentsPojo savedepartments(DepartmentsPojo departmentsPojo) throws JSONException {
        List<Departments> list=new ArrayList<>();
        if(departmentsPojo.getId()!=null) {
            list = departmentsRepository.findByNameAndIdNotIn(departmentsPojo.getName(),departmentsPojo.getId());
        }
        else{
            list=departmentsRepository.findByName(departmentsPojo.getName());
        }
        if(list.size()==0){
            Departments departments = null;
            departments = DepartmentsMapper.mapPojoToEntity(departmentsPojo);
            departmentsRepository.save(departments);
            return departmentsPojo;
        }
        else {
            return null;
        }
    }
    public DesignationPojo savedesignation(DesignationPojo designationPojo) throws JSONException {
        List<Designation> list=new ArrayList<>();
        if(designationPojo.getId()!=null) {
            list =designationRepository.findByNameAndIdNotIn(designationPojo.getName(),designationPojo.getId());
        }
        else{
            list=designationRepository.findByName(designationPojo.getName());
        }
        if(list.size()==0){
            Designation designation = null;
            designation = DesignationsMapper.mapPojoToEntity(designationPojo);
            designationRepository.save(designation);
            return designationPojo;
        }
        else {
            return null;
        }
    }

    public List<GuestsPojo> getGuestsList() {
        List<Guests> guests = new ArrayList<>();
        guests = (List<Guests>) hotelGuestsRepository.findAll();
        List<GuestsPojo> guestsPojo = ObjectMapperUtils.mapAll(guests, GuestsPojo.class);
        return guestsPojo;
    }
    public List<CurrencyPojo> getCurrencyList() {
        List<Currency> currencies = new ArrayList<>();
        currencies = (List<Currency>) hotelCurrencyRepository.findAll();
        List<CurrencyPojo> currencyPojos = ObjectMapperUtils.mapAll(currencies, CurrencyPojo.class);
        return currencyPojos;
    }
   public void getDeleteGuests(Long id){
        hotelGuestsRepository.delete(id);
   }
   public void getDeleteCurrency(Long id){
        hotelCurrencyRepository.delete(id);
   }
   public void getDeleteAmenities(Long acdyrId){
        amenitiesRepository.delete(acdyrId);
   }
   public void getDeleteHouseKeeping(Long id){
        houseKeepingRepository.delete(id);
   }
   public void getDeleteDepartments(Long id){
        departmentsRepository.delete(id);
   }
   public void getDeleteDesignation(Long id){
        designationRepository.delete(id);
   }
   public void getDeleteEmail(Long id){
        emailTemplateRepository.delete(id);
   }

    public FormSetUp saveOrUpdateformsetup(FormSetUpPojo formSetUpPojo) {
        FormSetUp formSetUps =new FormSetUp();
        if(formSetUpPojo.getFormsetupId()!=null){
            formSetUps=formSetupRepository.findAllByTypenameAndFormsetupIdNotIn(formSetUpPojo.getTypename(),formSetUpPojo.getFormsetupId());

        }else{
            formSetUps=formSetupRepository.findAllByTypename(formSetUpPojo.getTypename());
        }
        if(formSetUps==null){
            FormSetUp formSetUp = FormSetupMapper.mapFormSetUpPojoToEntity(formSetUpPojo);
            formSetupRepository.save(formSetUp);
            return formSetUp;
        }else{
            return null;
        }

    }

    public List<FormSetUpPojo> getFormSetupList() {
        List<FormSetUp> list = new ArrayList<>();
        list = formSetupRepository.findAll();
        List<FormSetUpPojo> formsetupDTOS = FormSetupMapper.mapFormSetupEntityToPojo(list);
        return formsetupDTOS;
    }
    public FormSetUpPojo editFormsetupMethod(String formsetupName) {
        FormSetUp formSetUp = formSetupRepository.findAllByTypename(formsetupName);
        List<FormSetUp> formSetUpList = new ArrayList<>();
        formSetUpList.add(formSetUp);
        FormSetUpPojo formSetUpPojo = FormSetupMapper.mapFormSetupEntityToPojo(formSetUpList).get(0);
        return formSetUpPojo;
    }
    public BasePojo getPaginatedfloorsList(BasePojo basePojo,String searchText) {
        List<Floors> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<Floors> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = hotelFloorRepository.findAllByNameContainingOrDescriptionContaining(searchText,searchText);
            }else {
                list1=hotelFloorRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
//            sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        }
        Floors floors=new Floors();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            floors=hotelFloorRepository.findFirstByNameContainingOrDescriptionContaining(searchText,searchText,sort);
            list = hotelFloorRepository.findAllByNameContainingOrDescriptionContaining(searchText,searchText,pageable);
        } else {
            floors=hotelFloorRepository.findFirstBy(sort);
            list = hotelFloorRepository.findAllBy(pageable);
        }
        if(list.contains(floors)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<FloorsPojo> floorList =FloorMapper.mapFloorEntityToPojo(list);
        basePojo=calculatePagination(basePojo,floorList.size());
        basePojo.setList(floorList);
        return basePojo;
    }
    public BasePojo getPaginatedRoomtypesList(BasePojo basePojo,String searchText) {
        List<RoomTypes> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<RoomTypes> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = hotelRoomTypesRepository.findAllByTitleContaining(searchText);
            }else {
                list1=hotelRoomTypesRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        RoomTypes roomTypes=new RoomTypes();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            roomTypes=hotelRoomTypesRepository.findFirstByTitleContaining(searchText,sort);
            list = hotelRoomTypesRepository.findAllByTitleContaining(searchText,pageable);
        } else {
            roomTypes=hotelRoomTypesRepository.findFirstBy(sort);
            list = hotelRoomTypesRepository.findAllBy(pageable);
        }
        if(list.contains(roomTypes)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<RoomTypesPojo> typesList = HotelRoomTypeMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedRoomList(BasePojo basePojo,String searchText) {
        List<Rooms> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<Rooms> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = hotelRoomsRepository.findAllByRoomnoContaining(searchText);
            }else {
                list1=hotelRoomsRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo( pageNo-1 );
            }
        }
        Rooms rooms=new Rooms();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            rooms=hotelRoomsRepository.findFirstByRoomnoContaining(searchText,sort);
            list = hotelRoomsRepository.findAllByRoomnoContaining(searchText,pageable);
        } else {
            rooms=hotelRoomsRepository.findFirstBy(sort);
            list = hotelRoomsRepository.findAllBy(pageable);
        }
        if(list.contains(rooms)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<RoomsPojo> typesList =HotelRoomsMapper.mapEntityToPojo(list);
        for(RoomsPojo roomsPojo1:typesList){
            roomsPojo1.setFloor_Id(roomsPojo1.getFloorId().getId());
            roomsPojo1.setRoom_typeId(roomsPojo1.getRoomTypeId().getId());
        }
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }

    public BasePojo getPaginatedPaidList(BasePojo basePojo,String searchText) {
        List<Services> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<Services> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = servicesRepository.findAllByTitleContaining(searchText);
            }else {
                list1=servicesRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageSize(size);
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        Services services=new Services();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            services=servicesRepository.findFirstByTitleContaining(searchText,sort);
            list = servicesRepository.findAllByTitleContaining(searchText,pageable);
        } else {
            services=servicesRepository.findFirstBy(sort);
            list = servicesRepository.findAllBy(pageable);
        }
        if(list.contains(services)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<ServicesPojo> typesList =ServiceMapper.mapEntityToPojo(list);
        for(ServicesPojo servicesPojo:typesList){
            servicesPojo.setRoomTypeId(servicesPojo.getRoomTypes().getId());
        }
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedPriceManagerList(BasePojo basePojo,String searchText) {
        List<PriceManager> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<PriceManager> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = hotelPriceManagerRepository.findAllByRoomtypeContaining(searchText);
            }else {
                list1=hotelPriceManagerRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else {
                basePojo.setPageNo(pageNo-1);
            }
        }
        PriceManager priceManager=new PriceManager();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            priceManager=hotelPriceManagerRepository.findFirstByRoomtypeContaining(searchText,sort);
            list = hotelPriceManagerRepository.findAllByRoomtypeContaining(searchText,pageable);
        } else {
            priceManager=hotelPriceManagerRepository.findFirstBy(sort);
            list = hotelPriceManagerRepository.findAllBy(pageable);
        }
        if(list.contains(priceManager)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<PriceManagerPojo> typesList =HotelPriceManagerMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedUsersList(BasePojo basePojo,String searchText) {
        List<User> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.ASC,"useraccountId"));
        if(basePojo.isLastPage()==true){
            List<User> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = hotelUserRepository.findAllByUserNameContaining(searchText);
            }else {
                list1=hotelUserRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            if(size!=0){
                basePojo.setPageSize(size);
            }
            sort=new Sort(new Sort.Order(Sort.Direction.DESC,"useraccountId"));
        }
        User user=new User();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.DESC,"useraccountId"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            user=hotelUserRepository.findFirstByUserNameContaining(searchText,sort);
            list = hotelUserRepository.findAllByUserNameContaining(searchText,pageable);
        } else {
            user=hotelUserRepository.findFirstBy(sort);
            list = hotelUserRepository.findAllBy(pageable);
        }
        if(list.contains(user)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<UserPojo> typesList =UserMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedCountryList(BasePojo basePojo,String searchText) {
        List<Country> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"countryId"));
        if(basePojo.isLastPage()==true){
            List<Country> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = countryRepository.findAllByCountryNameContaining(searchText);
            }else {
                list1=countryRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else {
                basePojo.setPageNo(pageNo-1);
            }
        }
        Country country=new Country();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"countryId"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            country=countryRepository.findFirstByCountryNameContaining(searchText,sort);
            list = countryRepository.findAllByCountryNameContaining(searchText,pageable);
        } else {
            country=countryRepository.findFirstBy(sort);
            list = countryRepository.findAllBy(pageable);
        }
        if(list.contains(country)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<CountryPojo> typesList =CountryMapper.mapCountryEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedCityList(BasePojo basePojo,String searchText) {
        List<Cities> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<Cities> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = cityRepository.findAllByNameContainingOrCountryContainingOrStateContaining(searchText,searchText,searchText);
            }else {
                list1=cityRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        Cities cities=new Cities();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            cities=cityRepository.findFirstByNameContaining(searchText,sort);
            list = cityRepository.findAllByNameContaining(searchText,pageable);
        } else {
            cities=cityRepository.findFirstBy(sort);
            list = cityRepository.findAllBy(pageable);
        }
        if(list.contains(cities)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<CityPojo> typesList =CityMapper.mapCitiesEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public List<MailDTO> getMailList() {
        List<Mail> list = new ArrayList<>();
        list = posMailRepository.findAll();
        List<MailDTO> mailDTOList = MailMapper.mapMailEntityToPojo(list);
        return mailDTOList;
    }
    public MailDTO editMail(String name) {
        Mail mail = posMailRepository.findByUserName(name);
        List<Mail> mails = new ArrayList<>();
        mails.add(mail);
        MailDTO mailDTO = MailMapper.mapMailEntityToPojo(mails).get(0);
        return mailDTO;
    }
    public void deleteMail(String  userName) {
        posMailRepository.delete(posMailRepository.findByUserName(userName));
    }
    public MailDTO createSaveMailDetails(MailDTO saveMailDetails) {
        Mail mail =posMailRepository.findOne(1L);
        if(mail==null)
        {
            mail=new Mail();
        }
        mail.setUserName(saveMailDetails.getUserName());
        mail.setPassword(saveMailDetails.getPassword());
        mail.setPort(saveMailDetails.getPort());
        mail.setSmtpHost(saveMailDetails.getSmtpHost());
        mail.setForMail(saveMailDetails.getForMail());
        mail.setStatus("Active");
        posMailRepository.save(mail);
        return saveMailDetails;
    }
    public void saveMailSchedule(MailSchedulerData mailSchedulerData) throws Exception {
        Mail mailServerPops = posMailRepository.findAll().get(0);
        mailSchedulerData.setFromMail(mailServerPops);
        String filename = null;
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        if (StringUtils.isNotEmpty(mailSchedulerData.getReportName()))
            switch (mailSchedulerData.getReportName()) {
                case "guestsList":
                    if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(mailSchedulerData.getReportType(), "application/pdf")) {
                        downloadGuestsListReportPdf(outputStream);
                        filename = "guestsReport.pdf";
                    } else {
                        downloadGuestsListReportExcel(outputStream);
                        filename = "guestsReport.xls";
                    }
                    break;
            }
        if (StringUtils.isEmpty(mailSchedulerData.getBody())) {
            mailSchedulerData.setBody("");
        }
        MailService.sendMailWithAttachment(mailSchedulerData.getFromMail(),
                mailSchedulerData.getToEmail(), "", mailSchedulerData.getSubject(),
                mailSchedulerData.getBody(), mailSchedulerData.getReportType(),
                outputStream.toByteArray(), filename);
    }
    public static BaseFont getcustomfont() {
        String relativeWebPath = "fonts/arial.ttf";
        return FontFactory.getFont("arial", BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 0.8f, Font.NORMAL, Color.BLACK).getBaseFont();
    }
    @Transactional
    public void downloadGuestsListReportPdf(OutputStream outputStream) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new com.lowagie.text.pdf.draw.LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new com.lowagie.text.pdf.draw.LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table = createFirstGuetsReport();
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstGuetsReport() {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable tab = new PdfPTable(1);
        Font f = new Font(getcustomfont(), 15, Font.BOLD, Color.WHITE);
        PdfPTable table = new PdfPTable(a + 5);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("GuestsListReport", f));
        p.setBackgroundColor(myColor);
        tab.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Name", font));
        pc2.setBackgroundColor(myColor);
        PdfPCell pc3 = new PdfPCell(new Phrase("Email", font));
        pc3.setBackgroundColor(myColor);
        PdfPCell pc4 = new PdfPCell(new Phrase("Address", font));
        pc4.setBackgroundColor(myColor);
        PdfPCell pc5 = new PdfPCell(new Phrase("Mobile No", font));
        pc5.setBackgroundColor(myColor);
        PdfPCell pc6 = new PdfPCell(new Phrase("DOB", font));
        pc6.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        table.addCell(pc5);
        table.addCell(pc6);
        List<GuestsPojo> guetsList =getGuestsList();
        for (GuestsPojo list : guetsList) {
            table.addCell(new Phrase(list.getFirstname() + "", font1));
            table.addCell(new Phrase(list.getEmail() + "", font1));
            table.addCell(new Phrase(list.getAddress() + "", font1));
            table.addCell(new Phrase(list.getMobile() + "", font1));
            table.addCell(new Phrase(list.getDob() + "", font1));
        }
        tab.addCell(table);
        return tab;
    }
    @Transactional
    public void downloadGuestsListReportExcel(OutputStream out) {
        try {
            List<GuestsPojo> guetsList =getGuestsList();
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            headerRow.createCell(0).setCellValue("GuestsListReport ");
            HSSFRow headerRow1 = sheet.createRow(1);
            headerRow1.createCell(0).setCellValue("Name");
            headerRow1.createCell(1).setCellValue("Email");
            headerRow1.createCell(2).setCellValue("Address");
            headerRow1.createCell(3).setCellValue("Mobile No");
            headerRow1.createCell(4).setCellValue("DOB");
            int i = 1;
            for (GuestsPojo list : guetsList) {
                HSSFRow row = sheet.createRow(++i);
                DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                row.createCell(0).setCellValue(list.getFirstname());
                row.createCell(1).setCellValue(list.getEmail());
                row.createCell(2).setCellValue(list.getAddress());
                row.createCell(3).setCellValue(list.getMobile());
                row.createCell(4).setCellValue(dateFormat.format(list.getDob()));
            }
            hwb.write(out);
            out.close();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }

    public BasePojo getPaginatedCurrency1List(BasePojo basePojo,String searchText) {
        List<Currency1> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"currencyId"));
        if(basePojo.isLastPage()==true){
            List<Currency1> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = currencyRepository.findAllByCurrencyNameContaining(searchText);
            }else {
                list1=currencyRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo( pageNo-1 );
            }
        }
        Currency1 currency1=new Currency1();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"currencyId"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            currency1=currencyRepository.findFirstByCurrencyNameContaining(searchText,sort);
            list = currencyRepository.findAllByCurrencyNameContaining(searchText,pageable);
        } else {
            currency1=currencyRepository.findFirstBy(sort);
            list = currencyRepository.findAllBy(pageable);
        }
        if(list.contains(currency1)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<CurrencyPojo1> currencyPojo1s =CurrencyMapper.mapCurrencyEntityToPojo(list);
        basePojo=calculatePagination(basePojo,currencyPojo1s.size());
        basePojo.setList(currencyPojo1s);
        return basePojo;
    }
    public BasePojo getPaginatedPaymentMethodList(BasePojo basePojo,String searchText) {
        List<PaymentMethod> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"paymentmethodId"));
        if(basePojo.isLastPage()==true){
            List<PaymentMethod> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = paymentMethodRepository.findAllByPaymentmethodNameContaining(searchText);
            }else {
                list1=paymentMethodRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        PaymentMethod paymentMethod=new PaymentMethod();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"paymentmethodId"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            paymentMethod=paymentMethodRepository.findFirstByPaymentmethodNameContaining(searchText,sort);
            list = paymentMethodRepository.findAllByPaymentmethodNameContaining(searchText,pageable);
        } else {
            paymentMethod=paymentMethodRepository.findFirstBy(sort);
            list = paymentMethodRepository.findAllBy(pageable);
        }
        if(list.contains(paymentMethod)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<PaymentMethodPojo> paymentMethodPojoList =PaymentMethodMapper.mapPaymentMethodEntityToPojo(list);
        basePojo=calculatePagination(basePojo,paymentMethodPojoList.size());
        basePojo.setList(paymentMethodPojoList);
        return basePojo;
    }
    public BasePojo getPaginatedCouponList(BasePojo basePojo,String searchText) {
        List<Coupons> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<Coupons> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = couponsRepository.findAllByTitleContaining(searchText);
            }else {
                list1=couponsRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        Coupons coupons=new Coupons();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            coupons=couponsRepository.findFirstByTitleContaining(searchText,sort);
            list = couponsRepository.findAllByTitleContaining(searchText,pageable);
        } else {
            coupons=couponsRepository.findFirstBy(sort);
            list = couponsRepository.findAllBy(pageable);
        }
        if(list.contains(coupons)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<CouponsPojo> couponsPojoList =CouponsMapper.mapCouponsEntityToPojo(list);
        basePojo=calculatePagination(basePojo,couponsPojoList.size());
        basePojo.setList(couponsPojoList);
        return basePojo;
    }
    public BasePojo getPaginatedAmenitiesList(BasePojo basePojo,String searchText) {
        List<Amenities> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"acdyrId"));
        if(basePojo.isLastPage()==true){
            List<Amenities> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = amenitiesRepository.findAllByNameContaining(searchText);
            }else {
                list1=amenitiesRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        Amenities amenities=new Amenities();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"acdyrId"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            amenities=amenitiesRepository.findFirstByNameContaining(searchText,sort);
            list = amenitiesRepository.findAllByNameContaining(searchText,pageable);
        } else {
            amenities=amenitiesRepository.findFirstBy(sort);
            list = amenitiesRepository.findAllBy(pageable);
        }
        if(list.contains(amenities)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<AmenitiesPojo> amenitiesPojoList =HotelAmenitiesMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,amenitiesPojoList.size());
        basePojo.setList(amenitiesPojoList);
        return basePojo;
    }
    public BasePojo getPaginatedHouseKeepingList(BasePojo basePojo,String searchText) {
        List<HouseKeepingStatus> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<HouseKeepingStatus> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = houseKeepingRepository.findAllByTitleContaining(searchText);
            }else {
                list1=houseKeepingRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        HouseKeepingStatus houseKeepingStatus=new HouseKeepingStatus();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
           houseKeepingStatus =houseKeepingRepository. findFirstByTitleContaining(searchText,sort) ;
            list = houseKeepingRepository.findAllByTitleContaining(searchText,pageable);
        } else {
            houseKeepingStatus=houseKeepingRepository.findFirstBy(sort);
            list = houseKeepingRepository.findAllBy(pageable);
        }
        if(list.contains(houseKeepingStatus)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<HouseKeepingStatusPojo> typesList =HouseKeepingStatusMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedDepartmentsList(BasePojo basePojo,String searchText) {
        List<Departments> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<Departments> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = departmentsRepository.findAllByNameContaining(searchText);
            }else {
                list1=departmentsRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        Departments departments=new Departments();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            departments=departmentsRepository.findFirstByNameContaining(searchText,sort);
            list = departmentsRepository.findAllByNameContaining(searchText,pageable);
        } else {
            departments=departmentsRepository.findFirstBy(sort);
            list = departmentsRepository.findAllBy(pageable);
        }
        if(list.contains(departments)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<DepartmentsPojo> typesList =DepartmentsMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedDesignationList(BasePojo basePojo,String searchText) {
        List<Designation> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<Designation> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = designationRepository.findAllByDeptname(searchText);
            }else {
                list1=designationRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        Designation designation=new Designation();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            designation=designationRepository.findFirstByDeptnameContaining(searchText,sort);
            list = designationRepository.findAllByDeptnameContaining(searchText,pageable);
        } else {
            designation=designationRepository.findFirstBy(sort);
            list = designationRepository.findAllBy(pageable);
        }
        if(list.contains(designation)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<DesignationPojo> typesList =DesignationsMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedEmployeesList(BasePojo basePojo,String searchText) {
        List<Employees> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<Employees> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = employeesRepository.findAllByUsernameContaining(searchText);
            }else {
                list1=employeesRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        Employees employees=new Employees();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            employees=employeesRepository.findFirstByUsernameContaining(searchText,sort);
            list = employeesRepository.findAllByUsernameContaining(searchText,pageable);
        } else {
            employees=employeesRepository.findFirstBy(sort);
            list = employeesRepository.findAllBy(pageable);
        }
        if(list.contains(employees)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<EmployeesPojo> typesList =EmployeesMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedTaxManagerList(BasePojo basePojo,String searchText) {
        List<taxes> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<taxes> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = hotelTaxRepository.findAllByNameContaining(searchText);
            }else {
                list1=hotelTaxRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        taxes taxes=new taxes();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            taxes=hotelTaxRepository.findFirstByNameContaining(searchText,sort);
            list = hotelTaxRepository.findAllByNameContaining(searchText,pageable);
        } else {
            taxes=hotelTaxRepository.findFirstBy(sort);
            list = hotelTaxRepository.findAllBy(pageable);
        }
        if(list.contains(taxes)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<TaxPojo> typesList =TaxMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedSalesDiscountList(BasePojo basePojo,String searchText) {
        List<SalesDiscount> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<SalesDiscount> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = salesDiscountRepository.findAllByItemNameContaining(searchText);
            }else {
                list1=salesDiscountRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        SalesDiscount salesDiscount=new SalesDiscount();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            salesDiscount=salesDiscountRepository.findFirstByItemNameContaining(searchText,sort);
            list = salesDiscountRepository.findAllByItemNameContaining(searchText,pageable);
        } else {
            salesDiscount=salesDiscountRepository.findFirstBy(sort);
            list = salesDiscountRepository.findAllBy(pageable);
        }
        if(list.contains(salesDiscount)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<SalesDiscountPojo> typesList =SalesDiscountMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedTestimonialsList(BasePojo basePojo,String searchText) {
        List<Testimonials> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<Testimonials> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = testimonialsRepository.findAllByAutherNameContaining(searchText);
            }else {
                list1=testimonialsRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        Testimonials testimonials=new Testimonials();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            testimonials=testimonialsRepository.findFirstByAutherNameContaining(searchText,sort);
            list = testimonialsRepository.findAllByAutherNameContaining(searchText,pageable);
        } else {
            testimonials=testimonialsRepository.findFirstBy(sort);
            list = testimonialsRepository.findAllBy(pageable);
        }
        if(list.contains(testimonials)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<TestimonialsPojo> typesList =TestimonialsMapper.mapEntityToPojo(list);
        for(TestimonialsPojo testimonialsPojo:typesList){
            testimonialsPojo.setRating( testimonialsPojo.getRating() );
        }
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedCurrencyList(BasePojo basePojo,String searchText) {
        List<Currency> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<Currency> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = hotelCurrencyRepository.findAllByNameContaining(searchText);
            }else {
                list1=hotelCurrencyRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        Currency currency=new Currency();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            currency=hotelCurrencyRepository.findFirstByNameContaining(searchText,sort);
            list = hotelCurrencyRepository.findAllByNameContaining(searchText,pageable);
        } else {
            currency=hotelCurrencyRepository.findFirstBy(sort);
            list = hotelCurrencyRepository.findAllBy(pageable);
        }
        if(list.contains(currency)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<CurrencyPojo> typesList =CurrencyMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedLanguageList(BasePojo basePojo,String searchText) {
        List<Language> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<Language> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = languageRepository.findAllByNameContaining(searchText);
            }else {
                list1=languageRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        Language language=new Language();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            language=languageRepository.findFirstByNameContaining(searchText,sort);
            list = languageRepository.findAllByNameContaining(searchText,pageable);
        } else {
            language=languageRepository.findFirstBy(sort);
            list = languageRepository.findAllBy(pageable);
        }
        if(list.contains(language)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<LanguagePojo> typesList =LanguageMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedExpenseCategoryList(BasePojo basePojo,String searchText) {
        List<ExpensesCategory> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<ExpensesCategory> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = expenseCategoryRepository.findAllByNameContaining(searchText);
            }else {
                list1=expenseCategoryRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        ExpensesCategory expensesCategory=new ExpensesCategory();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            expensesCategory=expenseCategoryRepository.findFirstByNameContaining(searchText,sort);
            list = expenseCategoryRepository.findAllByNameContaining(searchText,pageable);
        } else {
            expensesCategory=expenseCategoryRepository.findFirstBy(sort);
            list = expenseCategoryRepository.findAllBy(pageable);
        }
        if(list.contains(expensesCategory)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<ExpensesCategoryPojo> typesList =ExpenseCategoryMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedExpansesList(BasePojo basePojo,String searchText) {
        List<Expanses> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        if(basePojo.isLastPage()==true){
            List<Expanses> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = expenseRepository.findAllByTitleContaining(searchText);
            }else {
                list1=expenseRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            int pageNo=list1.size()/paginatedConstants;
            if(size!=0){
                basePojo.setPageNo(pageNo);
            }else{
                basePojo.setPageNo(pageNo-1);
            }
        }
        Expanses expanses=new Expanses();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            expanses=expenseRepository.findFirstByTitleContaining(searchText,sort);
            list = expenseRepository.findAllByTitleContaining(searchText,pageable);
        } else {
            expanses=expenseRepository.findFirstBy(sort);
            list = expenseRepository.findAllBy(pageable);
        }
        if(list.contains(expanses)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<ExpensesPojo> typesList =ExpenseMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    public BasePojo getPaginatedGuestsList(BasePojo basePojo,String searchText) {
        List<Guests> list = new ArrayList<>();
        basePojo.setPageSize(paginatedConstants);
        Sort sort=new Sort(new Sort.Order(Sort.Direction.ASC,"id"));
        if(basePojo.isLastPage()==true){
            List<Guests> list1=new ArrayList<>();
            if (!StringUtils.isEmpty(searchText)) {
                list1 = hotelGuestsRepository.findAllByLastnameContaining(searchText);
            }else {
                list1=hotelGuestsRepository.findAll();
            }
            int size=list1.size()%paginatedConstants;
            if(size!=0){
                basePojo.setPageSize(size);
            }
            sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        }
        Guests guests=new Guests();
        Pageable pageable=new PageRequest(basePojo.getPageNo(),basePojo.getPageSize(),sort);
        if(basePojo.isNextPage()==true || basePojo.isFirstPage()==true){
            sort=new Sort(new Sort.Order(Sort.Direction.DESC,"id"));
        }
        if (!StringUtils.isEmpty(searchText)) {
            guests=hotelGuestsRepository.findFirstByFirstnameAndLastnameContaining(searchText,sort);
            list = hotelGuestsRepository.findAllByLastnameContaining(searchText,pageable);
        } else {
            guests=hotelGuestsRepository.findFirstBy(sort);
            list = hotelGuestsRepository.findAllBy(pageable);
        }
        if(list.contains(guests)){
            basePojo.setStatus(true);
        }else {
            basePojo.setStatus(false);
        }
        List<GuestsPojo> typesList =HotelGuestsMapper.mapEntityToPojo(list);
        basePojo=calculatePagination(basePojo,typesList.size());
        basePojo.setList(typesList);
        return basePojo;
    }
    @Transactional
    public void downloadCountryPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table = createFirstTableCountry(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    private PdfPTable createFirstTableCountry(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 1);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Country", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Country Name", font));
        pc2.setBackgroundColor(myColor);
        table.addCell(pc2);
        List<CountryPojo> countryList = getCountryList(searchText);
        table.setWidthPercentage(100);
        for (CountryPojo countryPojo : countryList) {
            table.addCell(new Phrase(countryPojo.getCountryName() + "", font1));
        }
        table1.addCell(table);
        return table1;
    }
    public void downloadCountryExcelSheet(ByteArrayOutputStream outputStream,  String searchText) {
        try {
            List<CountryPojo> countryList = getCountryList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Country Name");
            int i = 0;
            for (CountryPojo country : countryList) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(country.getCountryName());
            }

            hwb.write(outputStream);
            outputStream.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    @Transactional
    public void downloadStatePdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table = createFirstTableState(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableState(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 2);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("State", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("State Name", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("Country Name", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        List<StatePojo> statePojoList = getStateList(searchText);
        table.setWidthPercentage(100);
        for (StatePojo statePojo : statePojoList) {
            table.addCell(new Phrase(statePojo.getStateName() + "", font1));
            table.addCell(new Phrase(statePojo.getCountry() + "", font1));
        }
        table1.addCell(table);
        return table1;
    }
    public void downloadStateExcelSheet(OutputStream out, String searchText) {
        try {
            List<StatePojo> statePojoList = getStateList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("State Name");
            headerRow1.createCell(1).setCellValue("Country Name");
            int i = 0;
            for (StatePojo statePojo : statePojoList) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(statePojo.getStateName());
                row.createCell(1).setCellValue(statePojo.getCountry());
            }

            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<StatePojo> getStateList(String searchText){
        List<State> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = stateRepository.findAllByStateCodeContainingOrStateNameContaining(searchText,searchText);
        } else {
            list = stateRepository.findAll();
        }
        List<StatePojo> stateList =StateMapper.mapStateEntityToPojo(list);
        return stateList;
    }
    @Transactional
    public void downloadFloorsPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table = createFirstTableFloors(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableFloors(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 3);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Floors", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Floors Name", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("Description", font));
        PdfPCell pc4 = new PdfPCell(new Phrase("Status", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        pc4.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        List<FloorsPojo> floorsPojoList = getFloorsPojoList(searchText);
        table.setWidthPercentage(100);
        for (FloorsPojo floorsPojo : floorsPojoList) {
            table.addCell(new Phrase(floorsPojo.getName() + "", font1));
            if(!StringUtils.isEmpty(floorsPojo.getDescription()))
                table.addCell(new Phrase(floorsPojo.getDescription() + "", font1));
            else
                table.addCell(new Phrase("" + "", font1));
            table.addCell(new Phrase(floorsPojo.getActive() + "", font1));
        }
        table1.addCell(table);
        return table1;
    }
    public void downloadFloorsExcelSheet(OutputStream out, String searchText) {
        try {
            List<FloorsPojo> floorsPojoList = getFloorsPojoList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Floors Name");
            headerRow1.createCell(1).setCellValue("Description");
            headerRow1.createCell(2).setCellValue("Status");
            int i = 0;
            for (FloorsPojo floorsPojo : floorsPojoList) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(floorsPojo.getName());
                row.createCell(1).setCellValue(floorsPojo.getDescription());
                row.createCell(2).setCellValue(floorsPojo.getActive());
            }

            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<FloorsPojo> getFloorsPojoList(String searchText){
        List<Floors> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = hotelFloorRepository.findAllByNameContainingOrDescriptionContaining(searchText,searchText);
        } else {
            list = hotelFloorRepository.findAll();
        }
        List<FloorsPojo> floorsPojoList =FloorMapper.mapFloorEntityToPojo(list);
        return floorsPojoList;
    }
@Transactional
public void downloadRoomsPdf(OutputStream outputStream,String searchText) {
    try {
        Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, outputStream);
        document.open();
        Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT);
        document.add(new Paragraph("", font1));
        Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT1);
        PdfPTable table;
        table = createFirstTableRooms(searchText);
        table.setHeaderRows(1);
        document.add(table);
        document.add(CONNECT1);
        Paragraph foot = new Paragraph();
        Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
        foot.add(ph5);
        document.add(foot);
        document.add(CONNECT);
        document.close();
    } catch (Exception e) {
        e.printStackTrace();

    }
}
    public PdfPTable createFirstTableRooms(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 3);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Rooms", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Room no", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("Floor", font));
        PdfPCell pc4 = new PdfPCell(new Phrase("RoomType", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        pc4.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        List<RoomsPojo> roomsPojoList = getRoomsPojoList(searchText);
        table.setWidthPercentage(100);
        for (RoomsPojo roomsPojo : roomsPojoList) {
            table.addCell(new Phrase(roomsPojo.getRoomno() + "", font1));
            if(roomsPojo.getFloorId()!=null) {
                table.addCell( new Phrase( roomsPojo.getFloorId().getName() + "", font1 ) );
            }else{
                table.addCell( new Phrase( "" + "", font1 ) );
            }
            if(roomsPojo.getRoomno()!=null) {
                table.addCell( new Phrase( roomsPojo.getRoomTypeId().getTitle() + "", font1 ) );

            }else {
                table.addCell( new Phrase( ""+"",font1 ) );
            }
        }
        table1.addCell(table);
        return table1;
    }
    public void downloadRoomsExcelSheet(OutputStream out, String searchText) {
        try {
            List<RoomsPojo> roomsPojoList = getRoomsPojoList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Room No");
            headerRow1.createCell(1).setCellValue("Floor");
            headerRow1.createCell(2).setCellValue("RoomType");
            int i = 0;
            for (RoomsPojo roomsPojo : roomsPojoList) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(roomsPojo.getRoomno());
                if(roomsPojo.getFloorId()!=null){
                    row.createCell(1).setCellValue(roomsPojo.getFloorId().getName());
                }else{
                    row.createCell( 1 ).setCellValue( "" );
                }
                if(roomsPojo.getRoomno()!=null){
                    row.createCell(2).setCellValue(roomsPojo.getRoomTypeId().getTitle());
                }else{
                    row.createCell( 2 ).setCellValue( "" );
                }
            }

            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<RoomsPojo> getRoomsPojoList(String searchText){
        List<Rooms> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = hotelRoomsRepository.findAllByRoomnoContaining(searchText);
        } else {
            list = hotelRoomsRepository.findAll();
        }
        List<RoomsPojo> roomsPojoList =HotelRoomsMapper.mapEntityToPojo(list);
        return roomsPojoList;
    }

    @Transactional
   public void downloadPaidServicesPdf(OutputStream outputStream,String searchText) {
    try {
        Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, outputStream);
        document.open();
        Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT);
        document.add(new Paragraph("", font1));
        Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT1);
        PdfPTable table;
        table = createFirstTablePaidServices(searchText);
        table.setHeaderRows(1);
        document.add(table);
        document.add(CONNECT1);
        Paragraph foot = new Paragraph();
        Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
        foot.add(ph5);
        document.add(foot);
        document.add(CONNECT);
        document.close();
    } catch (Exception e) {
        e.printStackTrace();

    }
}
    public PdfPTable createFirstTablePaidServices(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 7);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("PaidServices", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Title", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("Description", font));
        PdfPCell pc4 = new PdfPCell(new Phrase("RoomType", font));
        PdfPCell pc5 = new PdfPCell(new Phrase("Price", font));
        PdfPCell pc6 = new PdfPCell(new Phrase("Short Description", font));
        PdfPCell pc7 = new PdfPCell(new Phrase("Status", font));
        PdfPCell pc8 = new PdfPCell(new Phrase("Price Type", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        pc4.setBackgroundColor(myColor);
        pc5.setBackgroundColor(myColor);
        pc6.setBackgroundColor(myColor);
        pc7.setBackgroundColor(myColor);
        pc8.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        table.addCell(pc5);
        table.addCell(pc6);
        table.addCell(pc7);
        table.addCell(pc8);
        List<ServicesPojo> servicesPojoList = getServicesPojoList(searchText);
        table.setWidthPercentage(100);
        for (ServicesPojo servicesPojo : servicesPojoList) {
            table.addCell(new Phrase(servicesPojo.getTitle() + "", font1));
            table.addCell(new Phrase(servicesPojo.getDescription() + "", font1));
            table.addCell(new Phrase(servicesPojo.getRoomTypeId() + "", font1));
            table.addCell(new Phrase(servicesPojo.getPrice() + "", font1));
            table.addCell(new Phrase(servicesPojo.getShort_description() + "", font1));
            table.addCell(new Phrase(servicesPojo.getStatus() + "", font1));
            table.addCell(new Phrase(servicesPojo.getPrice_type() + "", font1));
        }
        table1.addCell(table);
        return table1;
    }
    public void downloadPaidServicesExcelSheet(OutputStream out, String searchText) {
        try {
            List<ServicesPojo> servicesPojoList = getServicesPojoList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Title");
            headerRow1.createCell(1).setCellValue("Description");
            headerRow1.createCell(2).setCellValue("RoomType");
            headerRow1.createCell(3).setCellValue("Price");
            headerRow1.createCell(4).setCellValue("Status");
            headerRow1.createCell(5).setCellValue("Short Description");
            headerRow1.createCell(6).setCellValue("Price Type");
            int i = 0;
            for (ServicesPojo servicesPojo : servicesPojoList) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(servicesPojo.getTitle());
                row.createCell(1).setCellValue(servicesPojo.getDescription());
                row.createCell(3).setCellValue(servicesPojo.getPrice());
                row.createCell(4).setCellValue(servicesPojo.getStatus());
                row.createCell(5).setCellValue(servicesPojo.getShort_description());
                row.createCell(6).setCellValue(servicesPojo.getPrice_type());
            }

            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<ServicesPojo> getServicesPojoList(String searchText){
        List<Services> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list =servicesRepository .findAllByTitleContainingOrDescriptionContaining(searchText,searchText);
        } else {
            list = servicesRepository.findAll();
        }
        List<ServicesPojo> servicesPojoList =ServiceMapper.mapEntityToPojo(list);
        return servicesPojoList;
    }
    @Transactional
   public void downloadPriceManagerPdf(OutputStream outputStream,String searchText) {
    try {
        Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, outputStream);
        document.open();
        Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT);
        document.add(new Paragraph("", font1));
        Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT1);
        PdfPTable table;
        table = createFirstTablePriceManager(searchText);
        table.setHeaderRows(1);
        document.add(table);
        document.add(CONNECT1);
        Paragraph foot = new Paragraph();
        Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
        foot.add(ph5);
        document.add(foot);
        document.add(CONNECT);
        document.close();
    } catch (Exception e) {
        e.printStackTrace();

    }
}
    public PdfPTable createFirstTablePriceManager(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 10);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("PriceManager", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Name", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("FromDate", font));
        PdfPCell pc4 = new PdfPCell(new Phrase("ToDate", font));
        PdfPCell pc5 = new PdfPCell(new Phrase("Monday", font));
        PdfPCell pc6 = new PdfPCell(new Phrase("Tuesday", font));
        PdfPCell pc7 = new PdfPCell(new Phrase("Wednesday", font));
        PdfPCell pc8 = new PdfPCell(new Phrase("Thursday", font));
        PdfPCell pc9 = new PdfPCell(new Phrase("Friday", font));
        PdfPCell pc10 = new PdfPCell(new Phrase("Saturday", font));
        PdfPCell pc11 = new PdfPCell(new Phrase("Sunday", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        pc4.setBackgroundColor(myColor);
        pc5.setBackgroundColor(myColor);
        pc6.setBackgroundColor(myColor);
        pc7.setBackgroundColor(myColor);
        pc8.setBackgroundColor(myColor);
        pc9.setBackgroundColor(myColor);
        pc10.setBackgroundColor(myColor);
        pc11.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        table.addCell(pc5);
        table.addCell(pc6);
        table.addCell(pc7);
        table.addCell(pc8);
        table.addCell(pc9);
        table.addCell(pc10);
        table.addCell(pc11);
        List<PriceManagerPojo> priceManagerPojoList = getPriceManagerPojos(searchText);
        table.setWidthPercentage(100);
        for (PriceManagerPojo priceManagerPojo : priceManagerPojoList) {
            table.addCell(new Phrase(priceManagerPojo.getRoomtype() + "", font1));
            table.addCell(new Phrase(priceManagerPojo.getFromDate() + "", font1));
            table.addCell(new Phrase(priceManagerPojo.getToDate() + "", font1));
            table.addCell(new Phrase(priceManagerPojo.getMon() + "", font1));
            table.addCell(new Phrase(priceManagerPojo.getTue() + "", font1));
            table.addCell(new Phrase(priceManagerPojo.getWed() + "", font1));
            table.addCell(new Phrase(priceManagerPojo.getThu() + "", font1));
            table.addCell(new Phrase(priceManagerPojo.getFri() + "", font1));
            table.addCell(new Phrase(priceManagerPojo.getSat() + "", font1));
            table.addCell(new Phrase(priceManagerPojo.getSun() + "", font1));

        }
        table1.addCell(table);
        return table1;
    }
    public void downloadPriceManagerExcelSheet(OutputStream out, String searchText) {
        try {
            List<PriceManagerPojo> priceManagerPojoList = getPriceManagerPojos(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("RoomType");
            headerRow1.createCell(1).setCellValue("From Date");
            headerRow1.createCell(2).setCellValue("To Date");
            headerRow1.createCell(3).setCellValue("Monday");
            headerRow1.createCell(4).setCellValue("Tuesday");
            headerRow1.createCell(5).setCellValue("Wednesday");
            headerRow1.createCell(6).setCellValue("Thursday");
            headerRow1.createCell(7).setCellValue("Friday");
            headerRow1.createCell(8).setCellValue("Saturday");
            headerRow1.createCell(9).setCellValue("Sunday");
            int i = 0;
            for (PriceManagerPojo priceManagerPojo : priceManagerPojoList) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(priceManagerPojo.getRoomtype());
//                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy");
//                String fromDate=simpleDateFormat.format(priceManagerPojo.getFromDate());
//                String toDate=simpleDateFormat.format(priceManagerPojo.getToDate());
                row.createCell(1).setCellValue(priceManagerPojo.getFromDate().toString());
                row.createCell(2).setCellValue(priceManagerPojo.getToDate().toString());
                row.createCell(3).setCellValue(priceManagerPojo.getMon());
                row.createCell(4).setCellValue(priceManagerPojo.getTue());
                row.createCell(5).setCellValue(priceManagerPojo.getWed());
                row.createCell(6).setCellValue(priceManagerPojo.getThu());
                row.createCell(7).setCellValue(priceManagerPojo.getFri());
                row.createCell(8).setCellValue(priceManagerPojo.getSat());
                row.createCell(9).setCellValue(priceManagerPojo.getSun());
            }

            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<PriceManagerPojo> getPriceManagerPojos(String searchText ){
        List<PriceManager> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list =hotelPriceManagerRepository .findAllByRoomtypeContaining(searchText);
        } else {
            list = hotelPriceManagerRepository.findAll();
        }
        List<PriceManagerPojo> priceManagerPojoList =HotelPriceManagerMapper.mapEntityToPojo(list);
        return priceManagerPojoList;
    }

    @Transactional
    public void downloadUsersPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table = createFirstTableUsers(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableUsers(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 8);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Users", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("User Name", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("Password", font));
        PdfPCell pc4 = new PdfPCell(new Phrase("Full Name", font));
        PdfPCell pc5 = new PdfPCell(new Phrase("Security Question", font));
        PdfPCell pc6 = new PdfPCell(new Phrase("Answer", font));
        PdfPCell pc7 = new PdfPCell(new Phrase("Telephone Number", font));
        PdfPCell pc8 = new PdfPCell(new Phrase("Email Address", font));
        PdfPCell pc9 = new PdfPCell(new Phrase("Status", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        pc4.setBackgroundColor(myColor);
        pc5.setBackgroundColor(myColor);
        pc6.setBackgroundColor(myColor);
        pc7.setBackgroundColor(myColor);
        pc8.setBackgroundColor(myColor);
        pc9.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        table.addCell(pc5);
        table.addCell(pc6);
        table.addCell(pc7);
        table.addCell(pc8);
        table.addCell(pc9);
        List<UserPojo> userPojoList = getUserPojoList(searchText);
        table.setWidthPercentage(100);
        for (UserPojo userPojo : userPojoList) {
            table.addCell(new Phrase(userPojo.getUserName() + "", font1));
            table.addCell(new Phrase(userPojo.getPasswordUser() + "", font1));
            table.addCell(new Phrase(userPojo.getFull_name() + "", font1));
            table.addCell(new Phrase(userPojo.getSecurityQuestion() + "", font1));
            table.addCell(new Phrase(userPojo.getSecurityAnswer() + "", font1));
            table.addCell(new Phrase(userPojo.getPhone() + "", font1));
            table.addCell(new Phrase(userPojo.getEmail() + "", font1));
            table.addCell(new Phrase(userPojo.getStatus() + "", font1));

        }
        table1.addCell(table);
        return table1;
    }
    public void downloadUsersExcelSheet(OutputStream out, String searchText) {
        try {
            List<UserPojo> userPojoList = getUserPojoList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("User Name");
            headerRow1.createCell(1).setCellValue("Password");
            headerRow1.createCell(2).setCellValue("Full Name");
            headerRow1.createCell(3).setCellValue("Security Question");
            headerRow1.createCell(4).setCellValue("Answer");
            headerRow1.createCell(5).setCellValue("Telephone Number");
            headerRow1.createCell(6).setCellValue("Email Address");
            headerRow1.createCell(7).setCellValue("Status");
            int i = 0;
            for (UserPojo usersPojo: userPojoList) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(usersPojo.getUserName());
                row.createCell(1).setCellValue(usersPojo.getPasswordUser());
                row.createCell(2).setCellValue(usersPojo.getFull_name());
                row.createCell(3).setCellValue(usersPojo.getSecurityQuestion());
                row.createCell(4).setCellValue(usersPojo.getSecurityAnswer());
                row.createCell(5).setCellValue(usersPojo.getPhone());
                row.createCell(6).setCellValue(usersPojo.getEmail());
                row.createCell(7).setCellValue(usersPojo.getStatus());
            }

            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<UserPojo> getUserPojoList(String searchText){
        List<User> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = hotelUserRepository.findByUserName(searchText);
        } else {
            list = hotelUserRepository.findAll();
        }
        List<UserPojo> userPojoList =UserMapper.mapEntityToPojo(list);
        return userPojoList;
    }



  @Transactional
   public void downloadCityPdf(OutputStream outputStream,String searchText) {
    try {
        Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, outputStream);
        document.open();
        Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT);
        document.add(new Paragraph("", font1));
        Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT1);
        PdfPTable table;
        table = createFirstTableCity(searchText);
        table.setHeaderRows(1);
        document.add(table);
        document.add(CONNECT1);
        Paragraph foot = new Paragraph();
        Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
        foot.add(ph5);
        document.add(foot);
        document.add(CONNECT);
        document.close();
    } catch (Exception e) {
        e.printStackTrace();

    }
}
    public PdfPTable createFirstTableCity(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a +3);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("City", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Country", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("State", font));
        PdfPCell pc4 = new PdfPCell(new Phrase("City Name", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        pc4.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        List<CityPojo> cityPojoList = getCityPojos(searchText);
        table.setWidthPercentage(100);
        for(CityPojo cityPojo:cityPojoList) {

            table.addCell( new Phrase( cityPojo.getCountry() + "", font1 ) );
            table.addCell( new Phrase( cityPojo.getState() + "", font1 ) );
            table.addCell( new Phrase( cityPojo.getName() + "", font1 ) );
        }

        table1.addCell(table);
        return table1;
    }
    public void downloadCityExcelSheet(OutputStream out, String searchText) {
        try {
            List<CityPojo> cityPojoList = getCityPojos(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Country");
            headerRow1.createCell(1).setCellValue("State");
            headerRow1.createCell(2).setCellValue("City Name");
            int i = 0;
            for (CityPojo cityPojo : cityPojoList) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(cityPojo.getState());
                row.createCell(1).setCellValue(cityPojo.getCountry());
                row.createCell(2).setCellValue(cityPojo.getName());
            }

            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<CityPojo> getCityPojos(String searchText ){
        List<Cities> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list =cityRepository .findAllByNameContaining(searchText);
        } else {
            list = cityRepository.findAll();
        }
        List<CityPojo> cityPojoList =CityMapper.mapCitiesEntityToPojo(list);
        return cityPojoList;
    }
  @Transactional
   public void downloadCurrency1Pdf(OutputStream outputStream,String searchText) {
    try {
        Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, outputStream);
        document.open();
        Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT);
        document.add(new Paragraph("", font1));
        Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT1);
        PdfPTable table;
        table = createFirstTableCurrency1(searchText);
        table.setHeaderRows(1);
        document.add(table);
        document.add(CONNECT1);
        Paragraph foot = new Paragraph();
        Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
        foot.add(ph5);
        document.add(foot);
        document.add(CONNECT);
        document.close();
    } catch (Exception e) {
        e.printStackTrace();

    }
}
    public PdfPTable createFirstTableCurrency1(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a +5);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Currency", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Currency Code", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("Currency Name", font));
        PdfPCell pc4 = new PdfPCell(new Phrase("Currency Description", font));
        PdfPCell pc5 = new PdfPCell(new Phrase("Currency Symbol", font));
        PdfPCell pc6 = new PdfPCell(new Phrase("Status", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        pc4.setBackgroundColor(myColor);
        pc5.setBackgroundColor(myColor);
        pc6.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        table.addCell(pc5);
        table.addCell(pc6);
        List<CurrencyPojo1> currencyPojo1s = getCurrencyList(searchText);
        table.setWidthPercentage(100);
        for(CurrencyPojo1 currencyPojo1:currencyPojo1s) {

            table.addCell( new Phrase( currencyPojo1.getCurrencyCode() + "", font1 ) );
            table.addCell( new Phrase( currencyPojo1.getCurrencyName() + "", font1 ) );
            table.addCell( new Phrase( currencyPojo1.getCurrencyDescription() + "", font1 ) );
            table.addCell( new Phrase( currencyPojo1.getCurrencySymbol() + "", font1 ) );
            table.addCell( new Phrase( currencyPojo1.getStatus() + "", font1 ) );
        }

        table1.addCell(table);
        return table1;
    }
    public void downloadCurrency1ExcelSheet(OutputStream out, String searchText) {
        try {
            List<CurrencyPojo1> currencyPojo1s = getCurrencyList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Currency Code");
            headerRow1.createCell(1).setCellValue("Currency Name");
            headerRow1.createCell(2).setCellValue("Currency Description");
            headerRow1.createCell(3).setCellValue("Currency Symbol");
            headerRow1.createCell(4).setCellValue("Status");
            int i = 0;
            for (CurrencyPojo1 currencyPojo1 : currencyPojo1s) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(currencyPojo1.getCurrencyCode());
                row.createCell(1).setCellValue(currencyPojo1.getCurrencyName());
                row.createCell(2).setCellValue(currencyPojo1.getCurrencyDescription());
                row.createCell(3).setCellValue(currencyPojo1.getCurrencySymbol());
                row.createCell(4).setCellValue(currencyPojo1.getStatus());
            }

            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<CurrencyPojo1> getCurrencyPojos(String searchText ){
        List<Currency1> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list =currencyRepository .findAllByCurrencyNameContaining(searchText);
        } else {
            list = currencyRepository.findAll();
        }
        List<CurrencyPojo1> currencyPojoList =CurrencyMapper.mapCurrencyEntityToPojo(list);
        return currencyPojoList;
    }
    @Transactional
   public void downloadPaymentMethodPdf(OutputStream outputStream,String searchText) {
    try {
        Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, outputStream);
        document.open();
        Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT);
        document.add(new Paragraph("", font1));
        Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT1);
        PdfPTable table;
        table = createFirstTablePaymentMethod(searchText);
        table.setHeaderRows(1);
        document.add(table);
        document.add(CONNECT1);
        Paragraph foot = new Paragraph();
        Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
        foot.add(ph5);
        document.add(foot);
        document.add(CONNECT);
        document.close();
    } catch (Exception e) {
        e.printStackTrace();

    }
}
    public PdfPTable createFirstTablePaymentMethod(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a +4);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Payment Method", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Payment Name", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("Payment Description", font));
        PdfPCell pc4 = new PdfPCell(new Phrase("Payment Type", font));
        PdfPCell pc5 = new PdfPCell(new Phrase("Status", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        pc4.setBackgroundColor(myColor);
        pc5.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        table.addCell(pc5);
        List<PaymentMethodPojo> paymentMethodPojos = getPaymentMethodPojos(searchText);
        table.setWidthPercentage(100);
        for(PaymentMethodPojo paymentMethodPojo:paymentMethodPojos) {

            table.addCell( new Phrase( paymentMethodPojo.getPaymentmethodName() + "", font1 ) );
            table.addCell( new Phrase( paymentMethodPojo.getPaymentmethodDescription() + "", font1 ) );
            table.addCell( new Phrase( paymentMethodPojo.getPaymentmethodType() + "", font1 ) );
            table.addCell( new Phrase( paymentMethodPojo.getStatus() + "", font1 ) );
        }

        table1.addCell(table);
        return table1;
    }
    public void downloadPaymentMethodExcelSheet(OutputStream out, String searchText) {
        try {
            List<PaymentMethodPojo> paymentMethodPojos = getPaymentMethodPojos(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Payment Name");
            headerRow1.createCell(1).setCellValue("Payment Description");
            headerRow1.createCell(2).setCellValue("Payment Type");
            headerRow1.createCell(3).setCellValue("Status");
            int i = 0;
            for (PaymentMethodPojo paymentMethodPojo : paymentMethodPojos) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(paymentMethodPojo.getPaymentmethodName());
                row.createCell(1).setCellValue(paymentMethodPojo.getPaymentmethodDescription());
                row.createCell(2).setCellValue(paymentMethodPojo.getPaymentmethodType());
                row.createCell(3).setCellValue(paymentMethodPojo.getStatus());
            }

            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<PaymentMethodPojo> getPaymentMethodPojos(String searchText ){
        List<PaymentMethod> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list =paymentMethodRepository .findAllByPaymentmethodNameContaining(searchText);
        } else {
            list = paymentMethodRepository.findAll();
        }
        List<PaymentMethodPojo> paymentMethodPojoList =PaymentMethodMapper.mapPaymentMethodEntityToPojo(list);
        return paymentMethodPojoList;
    }
    @Transactional
   public void downloadCouponPdf(OutputStream outputStream,String searchText) {
    try {
        Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, outputStream);
        document.open();
        Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT);
        document.add(new Paragraph("", font1));
        Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
        document.add(CONNECT1);
        PdfPTable table;
        table = createFirstTableCoupon(searchText);
        table.setHeaderRows(1);
        document.add(table);
        document.add(CONNECT1);
        Paragraph foot = new Paragraph();
        Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
        foot.add(ph5);
        document.add(foot);
        document.add(CONNECT);
        document.close();
    } catch (Exception e) {
        e.printStackTrace();

    }
}
    public PdfPTable createFirstTableCoupon(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a +9);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Coupon", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Offer Title", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("Description", font));
        PdfPCell pc4 = new PdfPCell(new Phrase("From Date", font));
        PdfPCell pc5 = new PdfPCell(new Phrase("To Date", font));
        PdfPCell pc6 = new PdfPCell(new Phrase("Coupon code", font));
        PdfPCell pc7 = new PdfPCell(new Phrase("Coupon value", font));
        PdfPCell pc8 = new PdfPCell(new Phrase("Coupon Type", font));
        PdfPCell pc9 = new PdfPCell(new Phrase("Minimum amount", font));
        PdfPCell pc10 = new PdfPCell(new Phrase("Maximum amount", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        pc4.setBackgroundColor(myColor);
        pc5.setBackgroundColor(myColor);
        pc6.setBackgroundColor(myColor);
        pc7.setBackgroundColor(myColor);
        pc8.setBackgroundColor(myColor);
        pc9.setBackgroundColor(myColor);
        pc10.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        table.addCell(pc5);
        table.addCell(pc6);
        table.addCell(pc7);
        table.addCell(pc8);
        table.addCell(pc9);
        table.addCell(pc10);
        List<CouponsPojo> couponsPojos = getCouponsPojos(searchText);
        table.setWidthPercentage(100);
        for(CouponsPojo couponsPojo:couponsPojos) {

            table.addCell( new Phrase( couponsPojo.getTitle() + "", font1 ) );
            table.addCell( new Phrase( couponsPojo.getDescription() + "", font1 ) );
            table.addCell( new Phrase( couponsPojo.getDate_from() + "", font1 ) );
            table.addCell( new Phrase( couponsPojo.getDate_to() + "", font1 ) );
            table.addCell( new Phrase( couponsPojo.getCode() + "", font1 ) );
            table.addCell( new Phrase( couponsPojo.getValue() + "", font1 ) );
            table.addCell( new Phrase( couponsPojo.getType() + "", font1 ) );
            table.addCell( new Phrase( couponsPojo.getMin_amount() + "", font1 ) );
            table.addCell( new Phrase( couponsPojo.getMax_amount() + "", font1  ));
        }

        table1.addCell(table);
        return table1;
    }
    public void downloadCouponExcelSheet(OutputStream out, String searchText) {
        try {
            List<CouponsPojo> couponsPojos = getCouponsPojos(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Offer Title");
            headerRow1.createCell(1).setCellValue("Description");
            headerRow1.createCell(2).setCellValue("From Date");
            headerRow1.createCell(3).setCellValue("To Date");
            headerRow1.createCell(4).setCellValue("Coupon Code");
            headerRow1.createCell(5).setCellValue("Coupon Type");
            headerRow1.createCell(6).setCellValue("Coupon Value");
            headerRow1.createCell(7).setCellValue("Minimum Amount");
            headerRow1.createCell(8).setCellValue("Maximum Amount");
            int i = 0;
            for (CouponsPojo couponsPojo : couponsPojos) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(couponsPojo.getTitle());
                row.createCell(1).setCellValue(couponsPojo.getDescription());
//                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy");
//                String year=simpleDateFormat.format(new Date());
                row.createCell( 2 ).setCellValue(couponsPojo.getDate_from().toString());
                row.createCell(3).setCellValue(couponsPojo.getDate_to().toString());
                row.createCell(4).setCellValue(couponsPojo.getCode());
                row.createCell(5).setCellValue(couponsPojo.getType());
                row.createCell(6).setCellValue(couponsPojo.getValue());
                row.createCell(7).setCellValue(couponsPojo.getMin_amount());
//                DecimalFormat df = new DecimalFormat("####0.00");
//                Double.parseDouble(df.format(amount));
                row.createCell(8).setCellValue( couponsPojo.getMax_amount());
            }

            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<CouponsPojo> getCouponsPojos(String searchText ){
        List<Coupons> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list =couponsRepository .findAllByTitleContaining(searchText);
        } else {
            list = couponsRepository.findAll();
        }
        List<CouponsPojo> couponsPojoList =CouponsMapper.mapCouponsEntityToPojo(list);
        return couponsPojoList;
    }

    @Transactional
    public void downloadRoomTypesPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableRoomTypes(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableRoomTypes(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 9);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("RoomTypes", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Title", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("Slug", font));
        PdfPCell pc4 = new PdfPCell(new Phrase("Short Code", font));
        PdfPCell pc5 = new PdfPCell(new Phrase("Description", font));
        PdfPCell pc6 = new PdfPCell(new Phrase("Base Occupancy", font));
        PdfPCell pc7 = new PdfPCell(new Phrase("Higher Occupancy", font));
        PdfPCell pc8 = new PdfPCell(new Phrase("Kids Occupancy", font));
        PdfPCell pc9 = new PdfPCell(new Phrase("Base Price", font));
        PdfPCell pc10 = new PdfPCell(new Phrase("Additional Person Price", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        pc4.setBackgroundColor(myColor);
        pc5.setBackgroundColor(myColor);
        pc6.setBackgroundColor(myColor);
        pc7.setBackgroundColor(myColor);
        pc8.setBackgroundColor(myColor);
        pc9.setBackgroundColor(myColor);
        pc10.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        table.addCell(pc5);
        table.addCell(pc6);
        table.addCell(pc7);
        table.addCell(pc8);
        table.addCell(pc9);
        table.addCell(pc10);
        List<RoomTypesPojo> roomTypesPojoList1 = getRoomTypesPojos(searchText);
        table.setWidthPercentage(100);
        for (RoomTypesPojo roomTypesPojo : roomTypesPojoList1) {
            table.addCell(new Phrase(roomTypesPojo.getTitle() + "", font1));
            table.addCell(new Phrase(roomTypesPojo.getSlug() + "", font1));
            table.addCell(new Phrase(roomTypesPojo.getShortcode() + "", font1));
            table.addCell(new Phrase(roomTypesPojo.getDescription() + "", font1));
            table.addCell(new Phrase(roomTypesPojo.getBase_occupancy() + "", font1));
            table.addCell(new Phrase(roomTypesPojo.getHigher_occupancy() + "", font1));
            table.addCell(new Phrase(roomTypesPojo.getKids_occupancy() + "", font1));
            table.addCell(new Phrase(roomTypesPojo.getBase_price() + "", font1));
            table.addCell(new Phrase(roomTypesPojo.getAdditional_person() + "", font1));

        }
        table1.addCell(table);
        return table1;
    }
    public void downloadRoomTypesExcelSheet(OutputStream out, String searchText) {
        try {
            List<RoomTypesPojo> roomTypesPojoList1 = getRoomTypesPojos(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Title");
            headerRow1.createCell(1).setCellValue("Slug");
            headerRow1.createCell(2).setCellValue("Shortcode");
            headerRow1.createCell(3).setCellValue("Description");
            headerRow1.createCell(4).setCellValue("Base Occupancy");
            headerRow1.createCell(5).setCellValue("Higher Occupancy");
            headerRow1.createCell(6).setCellValue("Kids Occupancy");
            headerRow1.createCell(7).setCellValue("Base Price");
            headerRow1.createCell(8).setCellValue("Additional Person Price");
            int i = 0;
            for (RoomTypesPojo roomTypesPojo : roomTypesPojoList1) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(roomTypesPojo.getTitle());
                row.createCell(1).setCellValue(roomTypesPojo.getSlug());
                row.createCell(2).setCellValue(roomTypesPojo.getShortcode());
                row.createCell(3).setCellValue(roomTypesPojo.getDescription());
                row.createCell(4).setCellValue(roomTypesPojo.getBase_occupancy());
                row.createCell(5).setCellValue(roomTypesPojo.getHigher_occupancy());
                row.createCell(6).setCellValue(roomTypesPojo.getKids_occupancy());
                row.createCell(7).setCellValue(roomTypesPojo.getBase_price());
                row.createCell(8).setCellValue(roomTypesPojo.getAdditional_person());
            }

            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<RoomTypesPojo> getRoomTypesPojos(String searchText){
        List<RoomTypes> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = hotelRoomTypesRepository.findAllByTitleContaining(searchText);
        } else {
            list = hotelRoomTypesRepository.findAll();
        }
        List<RoomTypesPojo> roomTypesPojos =HotelRoomTypeMapper.mapEntityToPojo(list);
        return roomTypesPojos;
    }
 @Transactional
    public void downloadAmenitiesPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableAmenities(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableAmenities(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 3);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Amenities", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Name", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("Description", font));
        PdfPCell pc4 = new PdfPCell(new Phrase("Status", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        pc4.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        List<AmenitiesPojo> amenitiesPojoList = getAmenitiesPojos(searchText);
        table.setWidthPercentage(100);
        for (AmenitiesPojo amenitiesPojo : amenitiesPojoList) {
            table.addCell(new Phrase(amenitiesPojo.getName() + "", font1));
            table.addCell(new Phrase(amenitiesPojo.getDescription() + "", font1));
            table.addCell(new Phrase(amenitiesPojo.getActive() + "", font1));

        }
        table1.addCell(table);
        return table1;
    }
    public void downloadAmenitiesExcelSheet(OutputStream out, String searchText) {
        try {
            List<AmenitiesPojo> amenitiesPojoList = getAmenitiesPojos(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Name");
            headerRow1.createCell(1).setCellValue("Description");
            headerRow1.createCell(2).setCellValue("Status");
            int i = 0;
            for (AmenitiesPojo amenitiesPojo : amenitiesPojoList) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(amenitiesPojo.getName());
                row.createCell(1).setCellValue(amenitiesPojo.getDescription());
                row.createCell(2).setCellValue(amenitiesPojo.getActive());
            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<AmenitiesPojo> getAmenitiesPojos(String searchText){
        List<Amenities> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = amenitiesRepository.findAllByNameContaining(searchText);
        } else {
            list = amenitiesRepository.findAll();
        }
        List<AmenitiesPojo> amenitiesPojos =HotelAmenitiesMapper.mapEntityToPojo(list);
        return amenitiesPojos;
    }

 @Transactional
    public void downloadHouseKeepingPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableHouseKeeping(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableHouseKeeping(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 3);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("House keeping", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Title", font));
        PdfPCell pc3 = new PdfPCell(new Phrase("Short Description", font));
        PdfPCell pc4 = new PdfPCell(new Phrase("Status", font));
        pc2.setBackgroundColor(myColor);
        pc3.setBackgroundColor(myColor);
        pc4.setBackgroundColor(myColor);
        table.addCell(pc2);
        table.addCell(pc3);
        table.addCell(pc4);
        List<HouseKeepingStatusPojo> houseKeepingStatusPojoList = getHouseKeepingStatusPojoList(searchText);
        table.setWidthPercentage(100);
        for (HouseKeepingStatusPojo houseKeepingStatusPojo : houseKeepingStatusPojoList) {
            table.addCell(new Phrase(houseKeepingStatusPojo.getTitle() + "", font1));
            table.addCell(new Phrase(houseKeepingStatusPojo.getShort_description() + "", font1));
            table.addCell(new Phrase(houseKeepingStatusPojo.getStatus() + "", font1));

        }
        table1.addCell(table);
        return table1;
    }
    public void downloadHouseKeepingExcelSheet(OutputStream out, String searchText) {
        try {
            List<HouseKeepingStatusPojo> houseKeepingStatusPojoList = getHouseKeepingStatusPojoList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Title");
            headerRow1.createCell(1).setCellValue("Short Description");
            headerRow1.createCell(2).setCellValue("Status");
            int i = 0;
            for (HouseKeepingStatusPojo houseKeepingStatusPojo : houseKeepingStatusPojoList) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(houseKeepingStatusPojo.getTitle());
                row.createCell(1).setCellValue(houseKeepingStatusPojo.getShort_description());
                row.createCell(2).setCellValue(houseKeepingStatusPojo.getStatus());
            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<HouseKeepingStatusPojo> getHouseKeepingStatusPojoList(String searchText){
        List<HouseKeepingStatus> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = houseKeepingRepository.findAllByTitleContaining(searchText);
        } else {
            list = houseKeepingRepository.findAll();
        }
        List<HouseKeepingStatusPojo> houseKeepingStatusPojos =HouseKeepingStatusMapper.mapEntityToPojo(list);
        return houseKeepingStatusPojos;
    }
 @Transactional
    public void downloadDepartmentsPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableDepartments(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableDepartments(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 1);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Departments", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Name", font));
        pc2.setBackgroundColor(myColor);
        table.addCell(pc2);
        List<DepartmentsPojo> departmentsPojoList = getDepartmentsPojoList(searchText);
        table.setWidthPercentage(100);
        for (DepartmentsPojo departmentsPojo : departmentsPojoList) {
            table.addCell(new Phrase(departmentsPojo.getName() + "", font1));

        }
        table1.addCell(table);
        return table1;
    }
    public void downloadDepartmentsExcelSheet(OutputStream out, String searchText) {
        try {
            List<DepartmentsPojo> departmentsPojos = getDepartmentsPojoList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Name");
            int i = 0;
            for (DepartmentsPojo departmentsPojo : departmentsPojos) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(departmentsPojo.getName());
            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<DepartmentsPojo> getDepartmentsPojoList(String searchText){
        List<Departments> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = departmentsRepository.findAllByNameContaining(searchText);
        } else {
            list = departmentsRepository.findAll();
        }
        List<DepartmentsPojo> departmentsPojos =DepartmentsMapper.mapEntityToPojo(list);
        return departmentsPojos;
    }
@Transactional
    public void downloadDesignationPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableDesignation(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableDesignation(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 2);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Designation", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Department Name", font));
        pc2.setBackgroundColor(myColor);
        table.addCell(pc2);
        PdfPCell pc3 = new PdfPCell(new Phrase("Name", font));
        pc3.setBackgroundColor( myColor );
        table.addCell( pc3 );
        List<DesignationPojo> designationPojos = getDesignationPojoList(searchText);
        table.setWidthPercentage(100);
        for (DesignationPojo designationPojo : designationPojos) {
            table.addCell(new Phrase(designationPojo.getDeptname() + "", font1));
            table.addCell(new Phrase(designationPojo.getName() + "", font1));

        }
        table1.addCell(table);
        return table1;
    }
    public void downloadDesignationExcelSheet(OutputStream out, String searchText) {
        try {
            List<DesignationPojo> designationPojos = getDesignationPojoList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Department Name");
            headerRow1.createCell(1).setCellValue("Name");
            int i = 0;
            for (DesignationPojo designationPojo : designationPojos) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(designationPojo.getDeptname());
                row.createCell(1).setCellValue(designationPojo.getName());
            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<DesignationPojo> getDesignationPojoList(String searchText){
        List<Designation> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = designationRepository.findAllByDeptnameContaining(searchText);
        } else {
            list = designationRepository.findAll();
        }
        List<DesignationPojo> designationPojos =DesignationsMapper.mapEntityToPojo(list);
        return designationPojos;
    }
@Transactional
    public void downloadEmployeesPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableEmployees(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableEmployees(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 11);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Employees", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("First Name", font));
        pc2.setBackgroundColor(myColor);
        table.addCell(pc2);
        PdfPCell pc3 = new PdfPCell(new Phrase("Last Name", font));
        pc3.setBackgroundColor(myColor);
        table.addCell(pc3);
        PdfPCell pc4 = new PdfPCell(new Phrase("UserName", font));
        pc4.setBackgroundColor(myColor);
        table.addCell(pc4);
        PdfPCell pc5= new PdfPCell(new Phrase("Email", font));
        pc5.setBackgroundColor(myColor);
        table.addCell(pc5);
        PdfPCell pc6 = new PdfPCell(new Phrase("Department", font));
        pc6.setBackgroundColor(myColor);
        table.addCell(pc6);
        PdfPCell pc7 = new PdfPCell(new Phrase("Designation", font));
        pc7.setBackgroundColor(myColor);
        table.addCell(pc7);
        PdfPCell pc8 = new PdfPCell(new Phrase("Country", font));
        pc8.setBackgroundColor(myColor);
        table.addCell(pc8);
        PdfPCell pc9 = new PdfPCell(new Phrase("State", font));
        pc9.setBackgroundColor(myColor);
        table.addCell(pc9);
        PdfPCell pc10 = new PdfPCell(new Phrase("City", font));
        pc10.setBackgroundColor(myColor);
        table.addCell(pc10);
        PdfPCell pc11 = new PdfPCell(new Phrase("Date Of Joining", font));
        pc11.setBackgroundColor(myColor);
        table.addCell(pc11);
        PdfPCell pc12 = new PdfPCell(new Phrase("Salary", font));
        pc12.setBackgroundColor(myColor);
        table.addCell(pc12);
        List<EmployeesPojo> employeesPojos = getEmployeesPojoList(searchText);
        table.setWidthPercentage(100);
        for (EmployeesPojo employeesPojo : employeesPojos) {
            table.addCell(new Phrase(employeesPojo.getFirstname() + "", font1));
            table.addCell(new Phrase(employeesPojo.getLastname() + "", font1));
            table.addCell(new Phrase(employeesPojo.getUsername() + "", font1));
            table.addCell(new Phrase(employeesPojo.getEmail() + "", font1));
            table.addCell(new Phrase(employeesPojo.getDepartment() + "", font1));
            table.addCell(new Phrase(employeesPojo.getDesignation() + "", font1));
            table.addCell(new Phrase(employeesPojo.getCountry() + "", font1));
            table.addCell(new Phrase(employeesPojo.getState() + "", font1));
            table.addCell(new Phrase(employeesPojo.getCity() + "", font1));
            table.addCell(new Phrase(employeesPojo.getJoin_date() + "", font1));
            table.addCell(new Phrase(employeesPojo.getSalary() + "", font1));

        }
        table1.addCell(table);
        return table1;
    }
    public void downloadEmployeesExcelSheet(OutputStream out, String searchText) {
        try {
            List<EmployeesPojo> employeesPojos = getEmployeesPojoList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("First Name");
            headerRow1.createCell(1).setCellValue("Last Name");
            headerRow1.createCell(2).setCellValue("UserName");
            headerRow1.createCell(3).setCellValue("Email");
            headerRow1.createCell(4).setCellValue("Department");
            headerRow1.createCell(5).setCellValue("Desination");
            headerRow1.createCell(6).setCellValue("Country");
            headerRow1.createCell(7).setCellValue("State");
            headerRow1.createCell(8).setCellValue("City");
            headerRow1.createCell(9).setCellValue("Date Of Joining");
            headerRow1.createCell(10).setCellValue("Salary");
            int i = 0;
            for (EmployeesPojo employeesPojo : employeesPojos) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(employeesPojo.getFirstname());
                row.createCell(1).setCellValue(employeesPojo.getLastname());
                row.createCell(2).setCellValue(employeesPojo.getUsername());
                row.createCell(3).setCellValue(employeesPojo.getEmail());
                row.createCell(4).setCellValue(employeesPojo.getDepartment());
                row.createCell(5).setCellValue(employeesPojo.getDesignation());
                row.createCell(6).setCellValue(employeesPojo.getCountry());
                row.createCell(7).setCellValue(employeesPojo.getState());
                row.createCell(8).setCellValue(employeesPojo.getCity());
                row.createCell(9).setCellValue(employeesPojo.getJoin_date().toString());
                row.createCell(10).setCellValue(employeesPojo.getSalary());
            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<EmployeesPojo> getEmployeesPojoList(String searchText){
        List<Employees> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = employeesRepository.findAllByUsernameContaining(searchText);
        } else {
            list = employeesRepository.findAll();
        }
        List<EmployeesPojo> employeesPojos =EmployeesMapper.mapEntityToPojo(list);
        return employeesPojos;
    }
@Transactional
    public void downloadExpenseCategoryPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableExpenseCategory(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableExpenseCategory(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 1);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("ExpenseCategory", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase(" Name", font));
        pc2.setBackgroundColor(myColor);
        table.addCell(pc2);
        List<ExpensesCategoryPojo> expensesCategoryPojos = getExpensesCategoryPojos(searchText);
        table.setWidthPercentage(100);
        for (ExpensesCategoryPojo expensesCategoryPojo : expensesCategoryPojos) {
            table.addCell(new Phrase(expensesCategoryPojo.getName() + "", font1));


        }
        table1.addCell(table);
        return table1;
    }
    public void downloadExpenseCategoryExcelSheet(OutputStream out, String searchText) {
        try {
            List<ExpensesCategoryPojo> expensesCategoryPojos = getExpensesCategoryPojos(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Name");
            int i = 0;
            for (ExpensesCategoryPojo expensesCategoryPojo : expensesCategoryPojos) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(expensesCategoryPojo.getName());
            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<ExpensesCategoryPojo> getExpensesCategoryPojos(String searchText){
        List<ExpensesCategory> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = expenseCategoryRepository.findAllByNameContaining(searchText);
        } else {
            list = expenseCategoryRepository.findAll();
        }
        List<ExpensesCategoryPojo> expensesCategoryPojos =ExpenseCategoryMapper.mapEntityToPojo(list);
        return expensesCategoryPojos;
    }

@Transactional
    public void downloadExpensePdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableExpense(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableExpense(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 5);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Expanses", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase(" Date", font));
        pc2.setBackgroundColor(myColor);
        table.addCell(pc2);
        PdfPCell pc3 = new PdfPCell(new Phrase(" Title", font));
        pc3.setBackgroundColor(myColor);
        table.addCell(pc3);
        PdfPCell pc4 = new PdfPCell(new Phrase(" Expense Category", font));
        pc4.setBackgroundColor(myColor);
        table.addCell(pc4);
        PdfPCell pc5 = new PdfPCell(new Phrase(" Amount", font));
        pc5.setBackgroundColor(myColor);
        table.addCell(pc5);
        PdfPCell pc6 = new PdfPCell(new Phrase(" Remarks", font));
        pc6.setBackgroundColor(myColor);
        table.addCell(pc6);
        List<ExpensesPojo> expensesPojos = getExpensesPojoList(searchText);
        table.setWidthPercentage(100);
        for (ExpensesPojo expensesPojo : expensesPojos) {
            table.addCell(new Phrase(expensesPojo.getDate() + "", font1));
            table.addCell(new Phrase(expensesPojo.getTitle() + "", font1));
            table.addCell(new Phrase(expensesPojo.getExpanses_category_id() + "", font1));
            table.addCell(new Phrase(expensesPojo.getAmount() + "", font1));
            table.addCell(new Phrase(expensesPojo.getRemarks() + "", font1));


        }
        table1.addCell(table);
        return table1;
    }
    public void downloadExpenseExcelSheet(OutputStream out, String searchText) {
        try {
            List<ExpensesPojo> expensesPojos = getExpensesPojoList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Date");
            headerRow1.createCell(1).setCellValue("Title");
            headerRow1.createCell(2).setCellValue("Expense Category");
            headerRow1.createCell(3).setCellValue("Amount");
            headerRow1.createCell(4).setCellValue("Remarks");
            int i = 0;
            for (ExpensesPojo expensesPojo : expensesPojos) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(expensesPojo.getDate().toString());
                row.createCell(1).setCellValue(expensesPojo.getTitle());
                row.createCell(2).setCellValue(expensesPojo.getExpanses_category_id());
                row.createCell(3).setCellValue(expensesPojo.getAmount());
                row.createCell(4).setCellValue(expensesPojo.getRemarks());
            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<ExpensesPojo> getExpensesPojoList(String searchText){
        List<Expanses> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = expenseRepository.findAllByTitleContaining(searchText);
        } else {
            list = expenseRepository.findAll();
        }
        List<ExpensesPojo> expensesPojos =ExpenseMapper.mapEntityToPojo(list);
        return expensesPojos;
    }
@Transactional
    public void downloadTaxManagerPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableTaxManager(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableTaxManager(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 9);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Tax Manager", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase(" Name", font));
        pc2.setBackgroundColor(myColor);
        table.addCell(pc2);
        PdfPCell pc3 = new PdfPCell(new Phrase(" Code", font));
        pc3.setBackgroundColor(myColor);
        table.addCell(pc3);
        PdfPCell pc4 = new PdfPCell(new Phrase(" Total Tax Rate", font));
        pc4.setBackgroundColor(myColor);
        table.addCell(pc4);
        PdfPCell pc5 = new PdfPCell(new Phrase(" CGST", font));
        pc5.setBackgroundColor(myColor);
        table.addCell(pc5);
        PdfPCell pc6 = new PdfPCell(new Phrase(" SGST", font));
        pc6.setBackgroundColor(myColor);
        table.addCell(pc6);
        PdfPCell pc7 = new PdfPCell(new Phrase(" IGST", font));
        pc7.setBackgroundColor(myColor);
        table.addCell(pc7);
        PdfPCell pc8 = new PdfPCell(new Phrase(" Status", font));
        pc8.setBackgroundColor(myColor);
        table.addCell(pc8);
        PdfPCell pc9 = new PdfPCell(new Phrase(" Minimum Amount", font));
        pc9.setBackgroundColor(myColor);
        table.addCell(pc9);
        PdfPCell pc10 = new PdfPCell(new Phrase(" Maximum Amount", font));
        pc10.setBackgroundColor(myColor);
        table.addCell(pc10);
        List<TaxPojo> taxPojos = getTaxPojos(searchText);
        table.setWidthPercentage(100);
        for (TaxPojo taxPojo : taxPojos) {
            table.addCell(new Phrase(taxPojo.getName() + "", font1));
            table.addCell(new Phrase(taxPojo.getCode() + "", font1));
            table.addCell(new Phrase(taxPojo.getRate() + "", font1));
            table.addCell(new Phrase(taxPojo.getCgst() + "", font1));
            table.addCell(new Phrase(taxPojo.getSgst() + "", font1));
            table.addCell(new Phrase(taxPojo.getIgst() + "", font1));
            table.addCell(new Phrase(taxPojo.getStatus() + "", font1));
            table.addCell(new Phrase(taxPojo.getMinimum_amount() + "", font1));
            table.addCell(new Phrase(taxPojo.getMax_amount() + "", font1));



        }
        table1.addCell(table);
        return table1;
    }
    public void downloadTaxManagerExcelSheet(OutputStream out, String searchText) {
        try {
            List<TaxPojo> taxPojos = getTaxPojos(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Name");
            headerRow1.createCell(1).setCellValue("Code");
            headerRow1.createCell(2).setCellValue("Total Tax Rate");
            headerRow1.createCell(3).setCellValue("CGST");
            headerRow1.createCell(4).setCellValue("SGST");
            headerRow1.createCell(5).setCellValue("IGST");
            headerRow1.createCell(6).setCellValue("Status");
            headerRow1.createCell(7).setCellValue("Minimum Amount");
            headerRow1.createCell(8).setCellValue("Maximum Amount");
            int i = 0;
            for (TaxPojo taxPojo : taxPojos) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(taxPojo.getName());
                row.createCell(1).setCellValue(taxPojo.getCode());
                row.createCell(2).setCellValue(taxPojo.getRate());
                row.createCell(3).setCellValue(taxPojo.getCgst());
                row.createCell(4).setCellValue(taxPojo.getSgst());
                row.createCell(5).setCellValue(taxPojo.getIgst());
                row.createCell(6).setCellValue(taxPojo.getStatus());
                row.createCell(7).setCellValue(taxPojo.getMinimum_amount());
                row.createCell(8).setCellValue(taxPojo.getMax_amount());
            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<TaxPojo> getTaxPojos(String searchText){
        List<taxes> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = hotelTaxRepository.findAllByNameContaining(searchText);
        } else {
            list = hotelTaxRepository.findAll();
        }
        List<TaxPojo> taxPojos =TaxMapper.mapEntityToPojo(list);
        return taxPojos;
    }
    @Transactional
    public void downloadGuestsPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableGuests(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableGuests(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 11);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Guests", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase(" First Name", font));
        pc2.setBackgroundColor(myColor);
        table.addCell(pc2);
        PdfPCell pc3 = new PdfPCell(new Phrase(" Last Name", font));
        pc3.setBackgroundColor(myColor);
        table.addCell(pc3);
        PdfPCell pc4 = new PdfPCell(new Phrase(" Gender", font));
        pc4.setBackgroundColor(myColor);
        table.addCell(pc4);
        PdfPCell pc5 = new PdfPCell(new Phrase(" Email", font));
        pc5.setBackgroundColor(myColor);
        table.addCell(pc5);
        PdfPCell pc6 = new PdfPCell(new Phrase(" Address", font));
        pc6.setBackgroundColor(myColor);
        table.addCell(pc6);
        PdfPCell pc7 = new PdfPCell(new Phrase(" Mobile", font));
        pc7.setBackgroundColor(myColor);
        table.addCell(pc7);
        PdfPCell pc8 = new PdfPCell(new Phrase(" Company Name", font));
        pc8.setBackgroundColor(myColor);
        table.addCell(pc8);
        PdfPCell pc9 = new PdfPCell(new Phrase(" Dob", font));
        pc9.setBackgroundColor(myColor);
        table.addCell(pc9);
        PdfPCell pc10 = new PdfPCell(new Phrase(" Country", font));
        pc10.setBackgroundColor(myColor);
        table.addCell(pc10);
        PdfPCell pc11 = new PdfPCell(new Phrase(" Status", font));
        pc11.setBackgroundColor(myColor);
        table.addCell(pc11);
        PdfPCell pc12 = new PdfPCell(new Phrase(" Vip", font));
        pc12.setBackgroundColor(myColor);
        table.addCell(pc12);
        List<GuestsPojo> guestsPojos = getGuestsPojos(searchText);
        table.setWidthPercentage(100);
        for (GuestsPojo guestsPojo : guestsPojos) {
            table.addCell(new Phrase(guestsPojo.getFirstname() + "", font1));
            table.addCell(new Phrase(guestsPojo.getLastname() + "", font1));
            table.addCell(new Phrase(guestsPojo.getGender() + "", font1));
            table.addCell(new Phrase(guestsPojo.getEmail() + "", font1));
            table.addCell(new Phrase(guestsPojo.getAddress() + "", font1));
            table.addCell(new Phrase(guestsPojo.getMobile() + "", font1));
            table.addCell(new Phrase(guestsPojo.getCompanyname() + "", font1));
            table.addCell(new Phrase(guestsPojo.getDob() + "", font1));
            table.addCell(new Phrase(guestsPojo.getCountry() + "", font1));
            table.addCell(new Phrase(guestsPojo.getStatus() + "", font1));
            table.addCell(new Phrase(guestsPojo.getVip() + "", font1));



        }
        table1.addCell(table);
        return table1;
    }
    public void downloadGuestsExcelSheet(OutputStream out, String searchText) {
        try {
            List<GuestsPojo> guestsPojos = getGuestsPojos(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("First Name");
            headerRow1.createCell(1).setCellValue("Last Name");
            headerRow1.createCell(2).setCellValue("Gender");
            headerRow1.createCell(3).setCellValue("Email");
            headerRow1.createCell(4).setCellValue("Address");
            headerRow1.createCell(5).setCellValue("Mobile");
            headerRow1.createCell(6).setCellValue("Company Name");
            headerRow1.createCell(7).setCellValue("Dob");
            headerRow1.createCell(8).setCellValue("Country");
            headerRow1.createCell(9).setCellValue("Status");
            headerRow1.createCell(10).setCellValue("Vip");
            int i = 0;
            for (GuestsPojo guestsPojo :guestsPojos) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(guestsPojo.getFirstname());
                row.createCell(1).setCellValue(guestsPojo.getLastname());
                row.createCell(2).setCellValue(guestsPojo.getGender());
                row.createCell(3).setCellValue(guestsPojo.getEmail());
                row.createCell(4).setCellValue(guestsPojo.getAddress());
                row.createCell(5).setCellValue(guestsPojo.getMobile());
                row.createCell(6).setCellValue(guestsPojo.getCompanyname());
                row.createCell(7).setCellValue(guestsPojo.getDob());
                row.createCell(8).setCellValue(guestsPojo.getCountry());
                row.createCell(9).setCellValue(guestsPojo.getStatus());
                row.createCell(10).setCellValue(guestsPojo.getVip());
            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<GuestsPojo> getGuestsPojos(String searchText){
        List<Guests> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = hotelGuestsRepository.findAllByLastnameContaining(searchText);
        } else {
            list = hotelGuestsRepository.findAll();
        }
        List<GuestsPojo> guestsPojos =HotelGuestsMapper.mapEntityToPojo(list);
        return guestsPojos;
    }
@Transactional
    public void downloadSalesDiscountPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableSalesDiscount(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableSalesDiscount(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a +6);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Sales Discount", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Item Name", font));
        pc2.setBackgroundColor(myColor);
        table.addCell(pc2);
        PdfPCell pc3 = new PdfPCell(new Phrase(" Discount Type", font));
        pc3.setBackgroundColor(myColor);
        table.addCell(pc3);
        PdfPCell pc4 = new PdfPCell(new Phrase(" Discount Value", font));
        pc4.setBackgroundColor(myColor);
        table.addCell(pc4);
        PdfPCell pc5 = new PdfPCell(new Phrase(" From Date", font));
        pc5.setBackgroundColor(myColor);
        table.addCell(pc5);
        PdfPCell pc6 = new PdfPCell(new Phrase(" To Date", font));
        pc6.setBackgroundColor(myColor);
        table.addCell(pc6);
        PdfPCell pc7 = new PdfPCell(new Phrase(" Status", font));
        pc7.setBackgroundColor(myColor);
        table.addCell(pc7);
        List<SalesDiscountPojo> salesDiscountPojos = getSalesDiscountPojos(searchText);
        table.setWidthPercentage(100);
        for (SalesDiscountPojo salesDiscountPojo : salesDiscountPojos) {
            table.addCell(new Phrase(salesDiscountPojo.getItemName() + "", font1));
            table.addCell(new Phrase(salesDiscountPojo.getDiscount_type() + "", font1));
            table.addCell(new Phrase(salesDiscountPojo.getDiscount_value() + "", font1));
            table.addCell(new Phrase(salesDiscountPojo.getFrom_date() + "", font1));
            table.addCell(new Phrase(salesDiscountPojo.getTo_date() + "", font1));
            table.addCell(new Phrase(salesDiscountPojo.getStatus() + "", font1));
        }
        table1.addCell(table);
        return table1;
    }
    public void downloadSalesDiscountExcelSheet(OutputStream out, String searchText) {
        try {
            List<SalesDiscountPojo> salesDiscountPojos = getSalesDiscountPojos(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Item Name");
            headerRow1.createCell(1).setCellValue("Discount Type");
            headerRow1.createCell(2).setCellValue("Discount Value");
            headerRow1.createCell(3).setCellValue("From Date");
            headerRow1.createCell(4).setCellValue("To Date");
            headerRow1.createCell(5).setCellValue("Status");
            int i = 0;
            for (SalesDiscountPojo salesDiscountPojo : salesDiscountPojos) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(salesDiscountPojo.getItemName());
                row.createCell(1).setCellValue(salesDiscountPojo.getDiscount_type());
                row.createCell(2).setCellValue(salesDiscountPojo.getDiscount_value());
                row.createCell(3).setCellValue(salesDiscountPojo.getFrom_date().toString());
                row.createCell(4).setCellValue(salesDiscountPojo.getTo_date().toString());
                row.createCell(5).setCellValue(salesDiscountPojo.getStatus());
            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<SalesDiscountPojo> getSalesDiscountPojos(String searchText){
        List<SalesDiscount> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = salesDiscountRepository.findAllByItemNameContaining(searchText);
        } else {
            list = salesDiscountRepository.findAll();
        }
        List<SalesDiscountPojo> salesDiscountPojos =SalesDiscountMapper.mapEntityToPojo(list);
        return salesDiscountPojos;
    }
@Transactional
    public void downloadTestimonialPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableTestimonial(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableTestimonial(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a + 5);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Sales Discount", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Auther Name", font));
        pc2.setBackgroundColor(myColor);
        table.addCell(pc2);
        PdfPCell pc3 = new PdfPCell(new Phrase(" Title", font));
        pc3.setBackgroundColor(myColor);
        table.addCell(pc3);
        PdfPCell pc4 = new PdfPCell(new Phrase(" Testimonial", font));
        pc4.setBackgroundColor(myColor);
        table.addCell(pc4);
        PdfPCell pc5 = new PdfPCell(new Phrase(" Rating", font));
        pc5.setBackgroundColor(myColor);
        table.addCell(pc5);
        PdfPCell pc6 = new PdfPCell(new Phrase(" Country", font));
        pc6.setBackgroundColor(myColor);
        table.addCell(pc6);
        List<TestimonialsPojo> testimonialsPojos = getTestimonialsPojos(searchText);
        table.setWidthPercentage(100);
        for (TestimonialsPojo testimonialsPojo : testimonialsPojos) {
            table.addCell(new Phrase(testimonialsPojo.getAutherName() + "", font1));
            table.addCell(new Phrase(testimonialsPojo.getTitle() + "", font1));
            table.addCell(new Phrase(testimonialsPojo.getTestimonial() + "", font1));
            table.addCell(new Phrase(testimonialsPojo.getRating() + "", font1));
            table.addCell(new Phrase(testimonialsPojo.getCountry() + "", font1));

        }
        table1.addCell(table);
        return table1;
    }
    public void downloadTestimonialExcelSheet(OutputStream out, String searchText) {
        try {
            List<TestimonialsPojo> testimonialsPojos = getTestimonialsPojos(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Auther Name");
            headerRow1.createCell(1).setCellValue("Title");
            headerRow1.createCell(2).setCellValue("Testimonial");
            headerRow1.createCell(3).setCellValue("Rating");
            headerRow1.createCell(4).setCellValue("Country");
            int i = 0;
            for (TestimonialsPojo testimonialsPojo : getTestimonialsList()) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(testimonialsPojo.getAutherName());
                row.createCell(1).setCellValue(testimonialsPojo.getTitle());
                row.createCell(2).setCellValue(testimonialsPojo.getTestimonial());
                row.createCell(3).setCellValue(testimonialsPojo.getRating());
                row.createCell(4).setCellValue(testimonialsPojo.getCountry());

            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<TestimonialsPojo> getTestimonialsPojos(String searchText){
        List<Testimonials> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = testimonialsRepository.findAllByAutherNameContaining(searchText);
        } else {
            list = testimonialsRepository.findAll();
        }
        List<TestimonialsPojo> testimonialsPojos =TestimonialsMapper.mapEntityToPojo(list);
        return testimonialsPojos;
    }
@Transactional
    public void downloadCurrencyPdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableCurrency(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableCurrency(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a +8);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Currency", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Country", font));
        pc2.setBackgroundColor(myColor);
        table.addCell(pc2);
        PdfPCell pc3 = new PdfPCell(new Phrase(" ISO ALPHA2", font));
        pc3.setBackgroundColor(myColor);
        table.addCell(pc3);
        PdfPCell pc4 = new PdfPCell(new Phrase(" ISO ALPHA3", font));
        pc4.setBackgroundColor(myColor);
        table.addCell(pc4);
        PdfPCell pc5 = new PdfPCell(new Phrase(" ISO NUMERIC", font));
        pc5.setBackgroundColor(myColor);
        table.addCell(pc5);
        PdfPCell pc6 = new PdfPCell(new Phrase(" Currency Code", font));
        pc6.setBackgroundColor(myColor);
        table.addCell(pc6);
        PdfPCell pc7 = new PdfPCell(new Phrase(" Currency Name", font));
        pc7.setBackgroundColor(myColor);
        table.addCell(pc7);
        PdfPCell pc8 = new PdfPCell(new Phrase(" Currency Symbol", font));
        pc8.setBackgroundColor(myColor);
        table.addCell(pc8);
        PdfPCell pc9 = new PdfPCell(new Phrase(" Status", font));
        pc9.setBackgroundColor(myColor);
        table.addCell(pc9);
        List<CurrencyPojo> currencyPojos = getCurrencyPojoList(searchText);
        table.setWidthPercentage(100);
        for (CurrencyPojo currencyPojo : currencyPojos) {
            table.addCell(new Phrase(currencyPojo.getName() + "", font1));
            table.addCell(new Phrase(currencyPojo.getIso_alpha2() + "", font1));
            table.addCell(new Phrase(currencyPojo.getIso_alpha3() + "", font1));
            table.addCell(new Phrase(currencyPojo.getIso_numeric() + "", font1));
            table.addCell(new Phrase(currencyPojo.getCurrency_code() + "", font1));
            table.addCell(new Phrase(currencyPojo.getCurrency_name() + "", font1));
            table.addCell(new Phrase(currencyPojo.getCurrrency_symbol() + "", font1));
            table.addCell(new Phrase(currencyPojo.getStatus() + "", font1));

        }
        table1.addCell(table);
        return table1;
    }
    public void downloadCurrencyExcelSheet(OutputStream out, String searchText) {
        try {
            List<CurrencyPojo> currencyPojos = getCurrencyPojoList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Country");
            headerRow1.createCell(1).setCellValue("ISO ALPHA2");
            headerRow1.createCell(2).setCellValue("ISO ALPHA3");
            headerRow1.createCell(3).setCellValue("ISO NUMERIC");
            headerRow1.createCell(4).setCellValue("Currency Code");
            headerRow1.createCell(5).setCellValue("Currency Name");
            headerRow1.createCell(6).setCellValue("Currency Symbol");
            headerRow1.createCell(7).setCellValue("Status");
            int i = 0;
            for (CurrencyPojo currencyPojo : getCurrencyList()) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(currencyPojo.getName());
                row.createCell(1).setCellValue(currencyPojo.getIso_alpha2());
                row.createCell(2).setCellValue(currencyPojo.getIso_alpha3());
                row.createCell(3).setCellValue(currencyPojo.getIso_numeric());
                row.createCell(4).setCellValue(currencyPojo.getCurrency_code());
                row.createCell(5).setCellValue(currencyPojo.getCurrency_name());
                row.createCell(6).setCellValue(currencyPojo.getCurrrency_symbol());
                row.createCell(7).setCellValue(currencyPojo.getStatus());

            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<CurrencyPojo> getCurrencyPojoList(String searchText){
        List<Currency> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = hotelCurrencyRepository.findAllByNameContaining(searchText);
        } else {
            list = hotelCurrencyRepository.findAll();
        }
        List<CurrencyPojo> currencyPojos =CurrencyMapper.mapEntityToPojo(list);
        return currencyPojos;
    }
@Transactional
    public void downloadLanguagePdf(OutputStream outputStream,String searchText) {
        try {
            Font font1 = new Font(getcustomfont(), 12F, Font.BOLD);
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();
            Chunk CONNECT = new Chunk(new LineSeparator(1, 100, Color.BLACK, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT);
            document.add(new Paragraph("", font1));
            Chunk CONNECT1 = new Chunk(new LineSeparator(1, 100, Color.WHITE, Element.ALIGN_JUSTIFIED, 3f));
            document.add(CONNECT1);
            PdfPTable table;
            table = createFirstTableLanguage(searchText);
            table.setHeaderRows(1);
            document.add(table);
            document.add(CONNECT1);
            Paragraph foot = new Paragraph();
            Phrase ph5 = new Phrase("Terms And Condition:Terms                    Prepared By                                        Approved By   ", font1);
            foot.add(ph5);
            document.add(foot);
            document.add(CONNECT);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
    public PdfPTable createFirstTableLanguage(String searchText) {
        Font font1 = new Font(getcustomfont(), 8, Font.NORMAL, Color.BLACK);
        int a = 0;
        PdfPTable table = new PdfPTable(a +1);
        PdfPTable table1 = new PdfPTable(a +1);
        Font font = new Font(getcustomfont(), 10, Font.NORMAL, Color.WHITE);
        Color myColor = WebColors.getRGBColor("#326397");
        PdfPCell p = new PdfPCell(new Phrase("Language", font));
        p.setBackgroundColor(myColor);
        table1.addCell(p);
        PdfPCell pc2 = new PdfPCell(new Phrase("Language Name", font));
        pc2.setBackgroundColor(myColor);
        table.addCell(pc2);
        List<LanguagePojo> languagePojos = getLanguagePojoList(searchText);
        table.setWidthPercentage(100);
        for (LanguagePojo languagePojo : languagePojos) {
            table.addCell(new Phrase(languagePojo.getName() + "", font1));
        }
        table1.addCell(table);
        return table1;
    }
    public void downloadLanguageExcelSheet(OutputStream out, String searchText) {
        try {
            List<LanguagePojo> languagePojos = getLanguagePojoList(searchText);
            HSSFWorkbook hwb = new HSSFWorkbook();
            HSSFSheet sheet = hwb.createSheet("First Sheet");
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints((2 * sheet.getDefaultRowHeightInPoints()));
            HSSFRow headerRow1 = sheet.createRow(0);
            headerRow1.createCell(0).setCellValue("Language Name");
            int i = 0;
            for (LanguagePojo languagePojo : getlanguageList()) {
                HSSFRow row = sheet.createRow(++i);
                row.createCell(0).setCellValue(languagePojo.getName());
            }
            hwb.write(out);
            out.close();
        } catch (IOException ioex) {
            ioex.printStackTrace();
        } catch (Exception gex) {
            gex.printStackTrace();
        }
    }
    public List<LanguagePojo> getLanguagePojoList(String searchText){
        List<Language> list = new ArrayList<>();
        if (!StringUtils.isEmpty(searchText)) {
            list = languageRepository.findAllByNameContaining(searchText);
        } else {
            list = languageRepository.findAll();
        }
        List<LanguagePojo> languagePojos =LanguageMapper.mapEntityToPojo(list);
        return languagePojos;
    }



}





