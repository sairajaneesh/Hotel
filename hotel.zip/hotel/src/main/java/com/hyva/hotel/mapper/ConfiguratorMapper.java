package com.hyva.hotel.mapper;

import com.hyva.hotel.entities.Configurator;
import com.hyva.hotel.pojo.ConfiguratorPojo;

public class ConfiguratorMapper {
    public static Configurator mapPojoToEntity(ConfiguratorPojo pojo){
        Configurator configurator=new Configurator();
        configurator.setId(pojo.getId());
        configurator.setConfiguratorName(pojo.getConfiguratorName());
        configurator.setDescription(pojo.getDescription());
        configurator.setHoursBased(pojo.getHoursBased());
        return configurator;
    }
}
