package com.hyva.hotel.respositories;

import com.hyva.hotel.entities.Configurator;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ConfiguratorRepository extends JpaRepository<Configurator, Long> {

}
