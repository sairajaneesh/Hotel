package com.hyva.hotel.respositories;

import com.hyva.hotel.entities.SMSServer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SMSServerRepository extends JpaRepository<SMSServer,Long> {
}
